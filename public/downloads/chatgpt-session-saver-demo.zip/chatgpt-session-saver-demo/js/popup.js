'use strict';

const STORAGE_KEY = 'chatGPTHistoryDemo';
const STORAGE_VERSION = 3;
const PENDING_ANSWER_TEXT = '[Answer not received yet]';
const AVERAGE_PAIR_PARSE_MS = 4250;
const MIN_PARSE_MS = 8000;
const MAX_PARSE_MS = 60 * 60 * 1000;
const CHECKPOINT_EVERY_UNITS = 10;
const PROGRESS_MESSAGE_TYPE = 'chatgpt_session_saver_progress';
const RUN_CANCEL_ATTR = 'data-chatgpt-session-saver-cancel-run-id';
const SCRAPE_MODE_LAST_10_PAIRS = 'last_10_pairs';
const SCRAPE_MODE_LAST_20_PAIRS = 'last_20_pairs';
const SCRAPE_MODE_LAST_30_PAIRS = 'last_30_pairs';
const SCRAPE_MODE_SET = new Set([
    SCRAPE_MODE_LAST_10_PAIRS,
    SCRAPE_MODE_LAST_20_PAIRS,
    SCRAPE_MODE_LAST_30_PAIRS
]);

let questionsColumnEl;
let answersColumnEl;
let questionsStatsEl;
let answersStatsEl;
let saveButtonEl;
let stopButtonEl;
let scrapeModeSelectEl;
let loadingPanelEl;
let loadingStatusEl;
let loadingPercentEl;
let loadingBarEl;
let loadingEtaEl;
let loadingIntervalId = null;
let pageCheckpointRefreshIntervalId = null;
let pageCheckpointRefreshInFlight = false;
let activeRunId = '';
let activeRunTabId = null;
let activeTotalPairs = 0;
let activeApproxPairEstimate = 0;
let activeStage2EstimatedDurationMs = 0;
let lastPersistedProgressCheckpointUnits = 0;
let latestProcessedPairs = 0;
let activeProgressUnit = 'pairs';
let activeScrapeMode = SCRAPE_MODE_LAST_10_PAIRS;
let liveMessages = [];
let liveMessageKeys = new Set();
let tailLiveQuestionLines = [];
let tailLiveAnswerLines = [];
let tailLiveRenderedPairs = 0;
let tailLiveKnownTotal = 0;
let tailLiveLastScrollProgress = 0;
let stage2StartedAtMs = 0;
let stopRequested = false;
let stopInProgress = false;
let currentQuestions = [];
let currentAnswers = [];
let questionsSearchInputEl;
let answersSearchInputEl;
let questionsSearchPrevEl;
let questionsSearchNextEl;
let questionsSearchCountEl;
let answersSearchPrevEl;
let answersSearchNextEl;
let answersSearchCountEl;
let questionsColumnRawText = '';
let answersColumnRawText = '';
let activeSearchColumn = 'questions';

const SEARCH_COLUMN_QUESTIONS = 'questions';
const SEARCH_COLUMN_ANSWERS = 'answers';
const SEARCH_COLUMN_SET = new Set([SEARCH_COLUMN_QUESTIONS, SEARCH_COLUMN_ANSWERS]);
const columnSearchState = {
    [SEARCH_COLUMN_QUESTIONS]: {
        query: '',
        matches: [],
        activeIndex: -1
    },
    [SEARCH_COLUMN_ANSWERS]: {
        query: '',
        matches: [],
        activeIndex: -1
    }
};

function normalizeText(text) {
    if (!text) {
        return '';
    }

    return text
        .replace(/\u00A0/g, ' ')
        .replace(/\r/g, '')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function splitMessagesByRole(messages) {
    const pairs = [];
    let currentQuestion = '';
    let currentAnswer = '';
    let hasActiveQuestion = false;

    function finalizePair() {
        if (!hasActiveQuestion) {
            return;
        }

        pairs.push({
            question: currentQuestion,
            answer: currentAnswer || PENDING_ANSWER_TEXT
        });

        currentQuestion = '';
        currentAnswer = '';
        hasActiveQuestion = false;
    }

    messages.forEach((message) => {
        if (!message || typeof message.text !== 'string') {
            return;
        }

        const text = normalizeText(message.text);
        if (!text) {
            return;
        }

        if (message.role === 'user') {
            if (!hasActiveQuestion) {
                currentQuestion = text;
                hasActiveQuestion = true;
                return;
            }

            finalizePair();
            currentQuestion = text;
            hasActiveQuestion = true;
            return;
        }

        if (message.role === 'assistant') {
            if (!hasActiveQuestion) {
                return;
            }

            if (!currentAnswer) {
                currentAnswer = text;
                return;
            }

            // Some answers are split into multiple assistant/tool segments.
            currentAnswer = `${currentAnswer}\n\n${text}`;
        }
    });

    finalizePair();

    const questions = [];
    const answers = [];
    pairs.forEach((pair, index) => {
        const pairNumber = index + 1;
        questions.push(`Question ${pairNumber}: ${pair.question}`);
        answers.push(`Answer ${pairNumber}:\n${pair.answer}`);
    });

    return { questions, answers };
}

function setCurrentColumnState(questions, answers) {
    currentQuestions = Array.isArray(questions) ? questions.slice() : [];
    currentAnswers = Array.isArray(answers) ? answers.slice() : [];
}

function formatCurrentPairsForExport() {
    const pairCount = Math.min(currentQuestions.length, currentAnswers.length);
    return Array.from({ length: pairCount }, (_, index) => {
        const number = index + 1;
        const questionText = currentQuestions[index].replace(/^Question\s+\d+:\s*/i, '').trim();
        const answerText = currentAnswers[index].replace(/^Answer\s+\d+:\s*/i, '').trim();

        return [
            `Question ${number}:`,
            questionText,
            '',
            `Answer ${number}:`,
            answerText,
            '',
            '------------------------------',
            ''
        ].join('\n');
    }).join('\n');
}

function downloadCurrentPairsAsText() {
    const content = formatCurrentPairsForExport();
    if (!content) {
        alert('No Q&A pairs to export yet.');
        return;
    }

    const now = new Date();
    const timestamp = [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0'),
        String(now.getHours()).padStart(2, '0'),
        String(now.getMinutes()).padStart(2, '0')
    ].join('-');
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    link.href = url;
    link.download = `chatgpt-session-export-${timestamp}.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

function buildColumnsFromMessages(messages, scrapeMode) {
    const { questions, answers } = splitMessagesByRole(messages);
    return { questions, answers };
}

function calculateStats(items) {
    return {
        count: items.length,
        characters: items.reduce((total, item) => total + item.length, 0)
    };
}

function renderStatsBadges(targetEl, itemLabel, count, characters) {
    if (!targetEl) {
        return;
    }

    const safeLabel = typeof itemLabel === 'string' ? itemLabel : 'Items';
    const safeCount = Number.isFinite(count) ? count : 0;
    const safeCharacters = Number.isFinite(characters) ? characters : 0;
    targetEl.innerHTML = `
        <span class="badge">${safeLabel}: ${safeCount}</span>
        <span class="badge">Characters: ${safeCharacters}</span>
    `;
}

function getSearchUiByColumn(column) {
    if (column === SEARCH_COLUMN_QUESTIONS) {
        return {
            contentEl: questionsColumnEl,
            inputEl: questionsSearchInputEl,
            prevButtonEl: questionsSearchPrevEl,
            nextButtonEl: questionsSearchNextEl,
            countEl: questionsSearchCountEl
        };
    }

    if (column === SEARCH_COLUMN_ANSWERS) {
        return {
            contentEl: answersColumnEl,
            inputEl: answersSearchInputEl,
            prevButtonEl: answersSearchPrevEl,
            nextButtonEl: answersSearchNextEl,
            countEl: answersSearchCountEl
        };
    }

    return null;
}

function getRawColumnText(column) {
    if (column === SEARCH_COLUMN_QUESTIONS) {
        return questionsColumnRawText;
    }

    if (column === SEARCH_COLUMN_ANSWERS) {
        return answersColumnRawText;
    }

    return '';
}

function setRawColumnText(column, text) {
    const safeText = typeof text === 'string' ? text : '';
    if (column === SEARCH_COLUMN_QUESTIONS) {
        questionsColumnRawText = safeText;
        return;
    }

    if (column === SEARCH_COLUMN_ANSWERS) {
        answersColumnRawText = safeText;
    }
}

function escapeHtml(text) {
    if (typeof text !== 'string' || text.length === 0) {
        return '';
    }

    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function collectSearchMatches(text, query) {
    if (!text || !query) {
        return [];
    }

    const source = text.toLocaleLowerCase();
    const needle = query.toLocaleLowerCase();
    if (!needle) {
        return [];
    }

    const matches = [];
    let fromIndex = 0;

    while (fromIndex < source.length) {
        const matchIndex = source.indexOf(needle, fromIndex);
        if (matchIndex < 0) {
            break;
        }

        matches.push({
            start: matchIndex,
            end: matchIndex + needle.length
        });
        fromIndex = matchIndex + Math.max(needle.length, 1);
    }

    return matches;
}

function renderHighlightedColumnHtml(text, matches, activeIndex) {
    if (!matches || matches.length === 0) {
        return escapeHtml(text);
    }

    let html = '';
    let cursor = 0;

    matches.forEach((match, index) => {
        const start = clamp(match.start, 0, text.length);
        const end = clamp(match.end, start, text.length);
        if (start > cursor) {
            html += escapeHtml(text.slice(cursor, start));
        }

        const markClass = index === activeIndex
            ? 'search-match search-match-active'
            : 'search-match';
        html += `<mark class="${markClass}">${escapeHtml(text.slice(start, end))}</mark>`;
        cursor = end;
    });

    if (cursor < text.length) {
        html += escapeHtml(text.slice(cursor));
    }

    return html;
}

function updateSearchControls(column) {
    const ui = getSearchUiByColumn(column);
    if (!ui) {
        return;
    }

    const state = columnSearchState[column];
    const matchCount = state.matches.length;
    const activeLabel = matchCount > 0 ? state.activeIndex + 1 : 0;

    if (ui.countEl) {
        ui.countEl.textContent = `${activeLabel}/${matchCount}`;
    }

    const hasMatches = matchCount > 0;
    if (ui.prevButtonEl) {
        ui.prevButtonEl.disabled = !hasMatches;
    }
    if (ui.nextButtonEl) {
        ui.nextButtonEl.disabled = !hasMatches;
    }
}

function scrollToActiveSearchMatch(column) {
    const ui = getSearchUiByColumn(column);
    if (!ui || !ui.contentEl) {
        return;
    }

    const state = columnSearchState[column];
    if (state.activeIndex < 0) {
        return;
    }

    const matchNodes = ui.contentEl.querySelectorAll('.search-match');
    const activeNode = matchNodes[state.activeIndex];
    if (!activeNode) {
        return;
    }

    activeNode.scrollIntoView({
        block: 'center',
        inline: 'nearest'
    });
}

function updateColumnSearchView(column, options = {}) {
    if (!SEARCH_COLUMN_SET.has(column)) {
        return;
    }

    const ui = getSearchUiByColumn(column);
    if (!ui || !ui.contentEl) {
        return;
    }

    const { scrollToActive = false } = options;
    const rawText = getRawColumnText(column);
    const state = columnSearchState[column];
    const query = state.query;
    const previousActiveIndex = state.activeIndex;
    state.matches = collectSearchMatches(rawText, query);

    if (state.matches.length === 0) {
        state.activeIndex = -1;
        ui.contentEl.textContent = rawText;
        updateSearchControls(column);
        return;
    }

    if (previousActiveIndex >= 0) {
        state.activeIndex = clamp(previousActiveIndex, 0, state.matches.length - 1);
    } else {
        state.activeIndex = 0;
    }

    ui.contentEl.innerHTML = renderHighlightedColumnHtml(rawText, state.matches, state.activeIndex);
    updateSearchControls(column);
    if (scrollToActive) {
        scrollToActiveSearchMatch(column);
    }
}

function applySearchQuery(column, query, shouldFocusMatch = false) {
    if (!SEARCH_COLUMN_SET.has(column)) {
        return;
    }

    const state = columnSearchState[column];
    state.query = typeof query === 'string' ? query : '';
    state.activeIndex = -1;
    updateColumnSearchView(column, { scrollToActive: shouldFocusMatch });
}

function moveSearchMatch(column, direction) {
    if (!SEARCH_COLUMN_SET.has(column)) {
        return;
    }

    const state = columnSearchState[column];
    const count = state.matches.length;
    if (count === 0) {
        return;
    }

    const step = direction < 0 ? -1 : 1;
    if (state.activeIndex < 0) {
        state.activeIndex = step > 0 ? 0 : count - 1;
    } else {
        state.activeIndex = (state.activeIndex + step + count) % count;
    }

    updateColumnSearchView(column, { scrollToActive: true });
}

function renderColumns(questions, answers, scrapeMode = activeScrapeMode) {
    const pairLimit = getTailModeLimit(scrapeMode);
    const safeQuestions = Array.isArray(questions) ? questions.slice(-pairLimit) : [];
    const safeAnswers = Array.isArray(answers) ? answers.slice(-pairLimit) : [];
    const questionsText = safeQuestions.join('\n\n');
    const answersText = safeAnswers.join('\n\n');

    setRawColumnText(SEARCH_COLUMN_QUESTIONS, questionsText);
    setRawColumnText(SEARCH_COLUMN_ANSWERS, answersText);
    updateColumnSearchView(SEARCH_COLUMN_QUESTIONS);
    updateColumnSearchView(SEARCH_COLUMN_ANSWERS);
    setCurrentColumnState(safeQuestions, safeAnswers);

    const questionStats = calculateStats(safeQuestions);
    const answerStats = calculateStats(safeAnswers);

    renderStatsBadges(questionsStatsEl, 'Questions', questionStats.count, questionStats.characters);
    renderStatsBadges(answersStatsEl, 'Answers', answerStats.count, answerStats.characters);
}

function clearColumns() {
    renderColumns([], []);
}

function clearUiForNewRun() {
    clearColumns();
    resetLiveParseState();
}

function clamp(value, minValue, maxValue) {
    return Math.max(minValue, Math.min(maxValue, value));
}

function formatDurationMs(durationMs) {
    const totalSeconds = Math.max(0, Math.round(durationMs / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function estimateParseDurationMs(pairCount) {
    if (!pairCount || pairCount <= 0) {
        return 20000;
    }

    return clamp(pairCount * AVERAGE_PAIR_PARSE_MS, MIN_PARSE_MS, MAX_PARSE_MS);
}

function formatApproxUnitEstimate(value, unitLabel) {
    const safeValue = getSafePairCount(value);
    if (safeValue <= 0) {
        return '';
    }

    if (safeValue < 10) {
        return `~${safeValue} ${unitLabel}`;
    }

    const step = safeValue >= 50 ? 10 : 5;
    const lowerBound = Math.max(1, Math.floor(safeValue / step) * step);
    const upperBound = lowerBound + step;
    return `~${lowerBound}-${upperBound} ${unitLabel}`;
}

function setLoadingProgress(percent, statusText, etaMs, estimatedPairs) {
    if (!loadingPanelEl) {
        return;
    }

    const safePercent = clamp(percent, 0, 100);
    const percentLabel = safePercent.toFixed(2);
    loadingPercentEl.textContent = `${percentLabel}%`;
    loadingBarEl.style.width = `${safePercent}%`;
    loadingStatusEl.textContent = statusText;

    if (saveButtonEl && saveButtonEl.disabled) {
        saveButtonEl.textContent = `Saving... ${percentLabel}%`;
    }

    const etaText = etaMs > 0 ? formatDurationMs(etaMs) : '0:00';
    const unitLabel = activeProgressUnit === 'messages' ? 'messages' : 'pairs';
    if (estimatedPairs > 0) {
        loadingEtaEl.textContent = `Approx wait: ~${etaText} (${estimatedPairs} ${unitLabel})`;
    } else if (activeApproxPairEstimate > 0) {
        loadingEtaEl.textContent = `Approx wait: ~${etaText} (${formatApproxUnitEstimate(activeApproxPairEstimate, unitLabel)})`;
    } else {
        loadingEtaEl.textContent = `Approx wait: ~${etaText}`;
    }
}

function clearLoadingTicker() {
    if (loadingIntervalId) {
        clearInterval(loadingIntervalId);
        loadingIntervalId = null;
    }
}

function getSafePairCount(value) {
    return Number.isFinite(value) && value > 0 ? Math.floor(value) : 0;
}

function countStoredPairs(messages) {
    if (!Array.isArray(messages) || messages.length === 0) {
        return 0;
    }

    return splitMessagesByRole(messages).questions.length;
}

function getStoredProgressState(payload) {
    const pairLimit = getTailModeLimit(payload && payload.scrapeMode);
    const messages = payload && Array.isArray(payload.messages) ? payload.messages : [];
    const derivedCurrentPairs = countStoredPairs(messages);
    const savedCurrentPairs = getSafePairCount(payload && payload.currentPairs);
    const legacyProcessedPairs = payload && payload.progressUnit !== 'messages'
        ? getSafePairCount(payload.processedUnits)
        : 0;
    const currentPairs = Math.min(
        pairLimit,
        Math.max(derivedCurrentPairs, savedCurrentPairs, legacyProcessedPairs)
    );

    let estimatedTotalPairs = getSafePairCount(payload && payload.estimatedTotalPairs);
    if (estimatedTotalPairs === 0 && payload && payload.progressUnit !== 'messages') {
        estimatedTotalPairs = getSafePairCount(payload.totalUnits);
    }
    if (estimatedTotalPairs === 0 && payload && payload.complete) {
        estimatedTotalPairs = currentPairs;
    }
    estimatedTotalPairs = Math.min(pairLimit, Math.max(currentPairs, estimatedTotalPairs));

    return {
        currentPairs,
        estimatedTotalPairs
    };
}

function restoreProgressFromStoredPayload(payload) {
    const storedStage = payload && typeof payload.stage === 'string' ? payload.stage : '';
    if (storedStage === 'stage1') {
        clearLoadingTicker();
        activeProgressUnit = 'pairs';
        activeApproxPairEstimate = 0;
        const stage1Percent = Number.isFinite(payload.stage1ProgressPercent)
            ? clamp(payload.stage1ProgressPercent, 0, 100)
            : 0;
        const stage1EtaMs = Number.isFinite(payload.etaMs)
            ? clamp(payload.etaMs, 0, MAX_PARSE_MS)
            : 0;
        setLoadingProgress(
            stage1Percent,
            'Stage 1/2: Loading full history...',
            stage1EtaMs,
            0
        );
        return;
    }

    const { currentPairs, estimatedTotalPairs } = getStoredProgressState(payload);
    if (currentPairs === 0) {
        if (storedStage === 'stage2' && estimatedTotalPairs > 0) {
            clearLoadingTicker();
            activeProgressUnit = 'pairs';
            activeApproxPairEstimate = 0;
            setLoadingProgress(
                0,
                `Stage 2/2: 0/${estimatedTotalPairs} pairs`,
                estimateParseDurationMs(estimatedTotalPairs),
                estimatedTotalPairs
            );
            return;
        }

        forceHideLoadingPanel();
        return;
    }

    clearLoadingTicker();
    activeProgressUnit = 'pairs';
    activeApproxPairEstimate = 0;

    const totalPairs = estimatedTotalPairs > 0 ? estimatedTotalPairs : currentPairs;
    const progressPercent = totalPairs > 0
        ? clamp((currentPairs / totalPairs) * 100, 0, 100)
        : 0;
    const remainingPairs = Math.max(0, totalPairs - currentPairs);
    const etaMs = clamp(remainingPairs * AVERAGE_PAIR_PARSE_MS, 0, MAX_PARSE_MS);
    const shouldAnimate = Boolean(payload && payload.checkpoint) && currentPairs < totalPairs;
    const statusText = shouldAnimate
        ? `Working: ${currentPairs}/${totalPairs} pairs`
        : (
            currentPairs >= totalPairs
                ? `Done: ${currentPairs}/${totalPairs} pairs`
                : `Saved: ${currentPairs}/${totalPairs} pairs`
        );

    setLoadingProgress(progressPercent, statusText, etaMs, totalPairs);

    if (!shouldAnimate) {
        return;
    }

    const nextCheckpointPairs = Math.min(
        totalPairs,
        (Math.floor(currentPairs / CHECKPOINT_EVERY_UNITS) + 1) * CHECKPOINT_EVERY_UNITS
    );
    const checkpointDistance = Math.max(1, nextCheckpointPairs - currentPairs);
    const nextCheckpointPercent = clamp((nextCheckpointPairs / totalPairs) * 100, progressPercent, 100);
    const animatedLimitPercent = Math.max(
        progressPercent,
        nextCheckpointPercent - Math.min(0.01, (nextCheckpointPercent - progressPercent) / 2)
    );
    const animationDurationMs = Math.max(1000, checkpointDistance * AVERAGE_PAIR_PARSE_MS);
    const startedAt = Date.now();

    loadingIntervalId = setInterval(() => {
        const elapsedMs = Date.now() - startedAt;
        const animationRatio = clamp(elapsedMs / animationDurationMs, 0, 1);
        const animatedPercent = progressPercent
            + ((animatedLimitPercent - progressPercent) * animationRatio);
        const remainingEtaMs = clamp(
            (remainingPairs * AVERAGE_PAIR_PARSE_MS) - elapsedMs,
            0,
            MAX_PARSE_MS
        );

        setLoadingProgress(animatedPercent, statusText, remainingEtaMs, totalPairs);

        if (animationRatio >= 1) {
            clearLoadingTicker();
        }
    }, 200);
}

function buildLiveMessageKey(message) {
    if (!message || typeof message !== 'object') {
        return '';
    }

    const role = typeof message.role === 'string' ? message.role : '';
    const text = typeof message.text === 'string' ? normalizeText(message.text) : '';
    if (!role || !text) {
        return '';
    }

    const id = typeof message.id === 'string' ? message.id.trim() : '';
    if (id) {
        return `${role}:id:${id}`;
    }

    const head = text.slice(0, 420);
    const tail = text.slice(-180);
    return `${role}:${text.length}:${head}:${tail}`;
}

function sortMessagesByKnownOrder(messages) {
    if (!Array.isArray(messages)) {
        return [];
    }

    return messages.slice().sort((leftMessage, rightMessage) => {
        const leftHasOrder = leftMessage && Number.isFinite(leftMessage.order);
        const rightHasOrder = rightMessage && Number.isFinite(rightMessage.order);
        if (leftHasOrder && rightHasOrder && leftMessage.order !== rightMessage.order) {
            return leftMessage.order - rightMessage.order;
        }

        if (leftHasOrder !== rightHasOrder) {
            return leftHasOrder ? -1 : 1;
        }

        return 0;
    });
}

function extractCompletedPairsFromMessages(messages) {
    if (!Array.isArray(messages) || messages.length === 0) {
        return [];
    }

    const pairs = [];
    let currentQuestion = '';
    let currentAnswer = '';
    let hasActiveQuestion = false;

    function finalizePair() {
        if (!hasActiveQuestion) {
            return;
        }

        const questionText = normalizeText(currentQuestion);
        const answerText = normalizeText(currentAnswer);
        if (questionText && answerText) {
            pairs.push({
                question: questionText,
                answer: answerText
            });
        }

        currentQuestion = '';
        currentAnswer = '';
        hasActiveQuestion = false;
    }

    messages.forEach((message) => {
        if (!message || typeof message.role !== 'string' || typeof message.text !== 'string') {
            return;
        }

        const text = normalizeText(message.text);
        if (!text) {
            return;
        }

        if (message.role === 'user') {
            if (!hasActiveQuestion) {
                currentQuestion = text;
                hasActiveQuestion = true;
                return;
            }

            finalizePair();
            currentQuestion = text;
            hasActiveQuestion = true;
            return;
        }

        if (message.role === 'assistant') {
            if (!hasActiveQuestion) {
                return;
            }

            if (!currentAnswer) {
                currentAnswer = text;
                return;
            }

            currentAnswer = `${currentAnswer}\n\n${text}`;
        }
    });

    finalizePair();
    return pairs;
}

function resetTailLiveState() {
    tailLiveQuestionLines = [];
    tailLiveAnswerLines = [];
    tailLiveRenderedPairs = 0;
    tailLiveKnownTotal = 0;
    tailLiveLastScrollProgress = 0;
}

function enqueueTailPairsForLiveRender(pairsChronological, reportedTotalPairs, scrollProgressPercent) {
    const safePairsChronological = Array.isArray(pairsChronological) ? pairsChronological : [];
    const safeTotal = getSafePairCount(reportedTotalPairs);
    if (safeTotal > 0) {
        tailLiveKnownTotal = safeTotal;
    } else if (tailLiveKnownTotal <= 0) {
        const fallbackLimit = getTailModeLimit(sanitizeScrapeMode(activeScrapeMode || getSelectedScrapeMode()));
        tailLiveKnownTotal = fallbackLimit > 0 ? fallbackLimit : 0;
    }

    tailLiveLastScrollProgress = Number.isFinite(scrollProgressPercent)
        ? clamp(scrollProgressPercent, 0, 100)
        : tailLiveLastScrollProgress;

    tailLiveQuestionLines = [];
    tailLiveAnswerLines = [];

    safePairsChronological.forEach((pair, index) => {
        if (!pair || typeof pair.question !== 'string' || typeof pair.answer !== 'string') {
            return;
        }

        const pairLabel = index + 1;
        tailLiveQuestionLines.push(`Question ${pairLabel}: ${normalizeText(pair.question)}`);
        tailLiveAnswerLines.push(`Answer ${pairLabel}:\n${normalizeText(pair.answer)}`);
    });

    tailLiveRenderedPairs = Math.min(tailLiveQuestionLines.length, tailLiveAnswerLines.length);
    renderColumns(tailLiveQuestionLines, tailLiveAnswerLines);

    const effectiveTotal = tailLiveKnownTotal > 0
        ? tailLiveKnownTotal
        : Math.max(tailLiveRenderedPairs, activeTotalPairs || 0);
    updateLivePairProgress(tailLiveRenderedPairs, effectiveTotal, tailLiveLastScrollProgress);
}

function resetLiveParseState() {
    liveMessages = [];
    liveMessageKeys = new Set();
    resetTailLiveState();
    stage2StartedAtMs = 0;
    latestProcessedPairs = 0;
    activeProgressUnit = 'pairs';
}

function sanitizeScrapeMode(mode) {
    return SCRAPE_MODE_SET.has(mode) ? mode : SCRAPE_MODE_LAST_10_PAIRS;
}

function getSelectedScrapeMode() {
    if (!scrapeModeSelectEl) {
        return SCRAPE_MODE_LAST_10_PAIRS;
    }

    return sanitizeScrapeMode(scrapeModeSelectEl.value);
}

function isTailLimitedMode(mode) {
    return (
        mode === SCRAPE_MODE_LAST_10_PAIRS
        || mode === SCRAPE_MODE_LAST_20_PAIRS
        || mode === SCRAPE_MODE_LAST_30_PAIRS
    );
}

function getTailModeLimit(mode) {
    if (mode === SCRAPE_MODE_LAST_10_PAIRS) {
        return 10;
    }

    if (mode === SCRAPE_MODE_LAST_20_PAIRS) {
        return 20;
    }

    if (mode === SCRAPE_MODE_LAST_30_PAIRS) {
        return 30;
    }

    return 10;
}

function takeLastPairsFromMessages(messages, pairLimit) {
    if (!Array.isArray(messages) || pairLimit <= 0) {
        return [];
    }

    const collectedReverse = [];
    let userCount = 0;

    for (let index = messages.length - 1; index >= 0; index -= 1) {
        const message = messages[index];
        if (!message || typeof message.role !== 'string' || typeof message.text !== 'string') {
            continue;
        }

        const normalizedText = normalizeText(message.text);
        if (!normalizedText) {
            continue;
        }

        collectedReverse.push({
            role: message.role,
            text: normalizedText,
            id: typeof message.id === 'string' ? message.id : '',
            order: Number.isFinite(message.order) ? message.order : null
        });

        if (message.role === 'user') {
            userCount += 1;
            if (userCount >= pairLimit) {
                break;
            }
        }
    }

    return collectedReverse.reverse();
}

function applyScrapeModeToMessages(messages, scrapeMode) {
    const mode = sanitizeScrapeMode(scrapeMode);
    if (!Array.isArray(messages) || messages.length === 0) {
        return [];
    }

    const normalizedMessages = messages
        .filter((message) => message && typeof message.role === 'string' && typeof message.text === 'string')
        .map((message) => ({
            role: message.role,
            text: normalizeText(message.text),
            id: typeof message.id === 'string' ? message.id : '',
            order: Number.isFinite(message.order) ? message.order : null
        }))
        .filter((message) => message.text.length > 0);

    return takeLastPairsFromMessages(normalizedMessages, getTailModeLimit(mode));
}

function appendLiveMessages(messagesChunk) {
    if (!Array.isArray(messagesChunk) || messagesChunk.length === 0) {
        return;
    }

    let changed = false;
    messagesChunk.forEach((message) => {
        const key = buildLiveMessageKey(message);
        if (!key || liveMessageKeys.has(key)) {
            return;
        }

        liveMessageKeys.add(key);
        liveMessages.push({
            role: message.role,
            text: normalizeText(message.text || ''),
            id: typeof message.id === 'string' ? message.id : '',
            order: Number.isFinite(message.order) ? message.order : null
        });
        changed = true;
    });

    if (!changed) {
        return;
    }

    const mode = sanitizeScrapeMode(activeScrapeMode || getSelectedScrapeMode());
    liveMessages = sortMessagesByKnownOrder(liveMessages);
    const visibleMessages = applyScrapeModeToMessages(liveMessages, mode);
    const { questions, answers } = buildColumnsFromMessages(visibleMessages, mode);
    renderColumns(questions, answers);
}

function replaceLiveMessages(messages) {
    if (!Array.isArray(messages)) {
        return;
    }

    liveMessages = [];
    liveMessageKeys = new Set();

    messages.forEach((message) => {
        const key = buildLiveMessageKey(message);
        if (!key || liveMessageKeys.has(key)) {
            return;
        }

        liveMessageKeys.add(key);
        liveMessages.push({
            role: message.role,
            text: normalizeText(message.text || ''),
            id: typeof message.id === 'string' ? message.id : '',
            order: Number.isFinite(message.order) ? message.order : null
        });
    });

    const mode = sanitizeScrapeMode(activeScrapeMode || getSelectedScrapeMode());
    liveMessages = sortMessagesByKnownOrder(liveMessages);
    const visibleMessages = applyScrapeModeToMessages(liveMessages, mode);
    const { questions, answers } = buildColumnsFromMessages(visibleMessages, mode);
    renderColumns(questions, answers);
}

function updateLivePairProgress(processedPairs, totalPairs, scrollProgressPercent) {
    const now = Date.now();
    const mode = sanitizeScrapeMode(activeScrapeMode || getSelectedScrapeMode());
    const isTailMode = isTailLimitedMode(mode);
    const safeProcessed = Math.max(0, Math.floor(Number.isFinite(processedPairs) ? processedPairs : 0));
    const safeTotal = getSafePairCount(totalPairs);
    const safeScrollProgress = Number.isFinite(scrollProgressPercent)
        ? clamp(scrollProgressPercent, 0, 100)
        : 0;

    latestProcessedPairs = safeProcessed;
    if (stage2StartedAtMs === 0 && safeProcessed > 0) {
        stage2StartedAtMs = now;
    }

    let etaMs = 0;
    let stage2Percent = 0;
    const unitLabel = activeProgressUnit === 'messages' ? 'messages' : 'pairs';
    let displayProcessed = safeProcessed;
    let displayTotal = safeTotal;

    if (safeTotal > 0) {
        stage2Percent = clamp((safeProcessed / safeTotal) * 100, 0, 100);
        const remainingPairs = Math.max(0, safeTotal - safeProcessed);
        if (isTailMode) {
            etaMs = remainingPairs * 3000;
        } else {
            etaMs = remainingPairs * AVERAGE_PAIR_PARSE_MS;
        }
    } else if (safeScrollProgress > 0) {
        stage2Percent = safeScrollProgress;
    }

    if (!isTailMode && activeStage2EstimatedDurationMs > 0 && stage2StartedAtMs > 0) {
        etaMs = Math.max(0, activeStage2EstimatedDurationMs - (now - stage2StartedAtMs));
        if (stage2Percent >= 99.5) {
            etaMs = 0;
        }
    } else if (etaMs > 0) {
        etaMs = clamp(etaMs, 0, MAX_PARSE_MS);
    }

    if (safeTotal > 0) {
        displayTotal = Math.max(safeTotal, safeProcessed);
        setLoadingProgress(stage2Percent, `Stage 2/2: ${displayProcessed}/${displayTotal} ${unitLabel}`, etaMs, displayTotal);
        return;
    }

    displayTotal = Math.max(safeProcessed, 1);
    setLoadingProgress(stage2Percent, `Stage 2/2: ${displayProcessed}/${displayTotal} ${unitLabel}`, etaMs, 0);
}

function handleRuntimeProgressMessage(message, sender) {
    if (!message || message.type !== PROGRESS_MESSAGE_TYPE) {
        return;
    }

    if (!activeRunId || message.runId !== activeRunId) {
        return;
    }

    if (
        Number.isInteger(activeRunTabId)
        && sender
        && sender.tab
        && Number.isInteger(sender.tab.id)
        && sender.tab.id !== activeRunTabId
    ) {
        return;
    }

    const stage = typeof message.stage === 'string' ? message.stage : '';
    if (stage === 'stage1') {
        const progressPercent = Number.isFinite(message.progressPercent) ? clamp(message.progressPercent, 0, 100) : 0;
        const etaMs = Number.isFinite(message.etaMs) ? clamp(message.etaMs, 0, MAX_PARSE_MS) : 0;
        setLoadingProgress(progressPercent, 'Stage 1/2: Loading full history...', etaMs, 0);
        return;
    }

    if (stage !== 'stage2') {
        return;
    }

    const runtimeUnit = message.progressUnit === 'messages' ? 'messages' : 'pairs';
    activeProgressUnit = runtimeUnit;
    const mode = sanitizeScrapeMode(activeScrapeMode || getSelectedScrapeMode());
    const isTailMode = isTailLimitedMode(mode);
    const rawTotalPairs = Number.isFinite(message.totalUnits)
        ? message.totalUnits
        : (Number.isFinite(message.totalPairs) ? message.totalPairs : activeTotalPairs);
    const totalPairs = getSafePairCount(rawTotalPairs);
    const processedPairs = Number.isFinite(message.processedUnits)
        ? message.processedUnits
        : (Number.isFinite(message.processedPairs) ? message.processedPairs : 0);
    const scrollProgressPercent = Number.isFinite(message.scrollProgressPercent) ? message.scrollProgressPercent : 0;
    if (totalPairs > 0) {
        activeTotalPairs = totalPairs;
    }

    if (isTailMode) {
        if (Array.isArray(message.fullMessages)) {
            const pairLimit = getTailModeLimit(mode);
            const completedPairsChronological = extractCompletedPairsFromMessages(message.fullMessages);
            const limitedPairs = pairLimit > 0
                ? completedPairsChronological.slice(-pairLimit)
                : completedPairsChronological;
            enqueueTailPairsForLiveRender(limitedPairs, totalPairs, scrollProgressPercent);
            persistProgressCheckpoint(message.fullMessages, {
                source: 'popup-progress-checkpoint',
                scrapeMode: mode,
                runId: activeRunId,
                processedUnits: processedPairs,
                totalUnits: totalPairs,
                progressUnit: runtimeUnit
            });
        }

        return;
    }

    if (Array.isArray(message.fullMessages)) {
        replaceLiveMessages(message.fullMessages);
    } else if (Array.isArray(message.messagesChunk) && message.messagesChunk.length > 0) {
        appendLiveMessages(message.messagesChunk);
    }

    updateLivePairProgress(processedPairs, totalPairs, scrollProgressPercent);
    persistProgressCheckpoint(applyScrapeModeToMessages(liveMessages, mode), {
        source: 'popup-progress-checkpoint',
        scrapeMode: mode,
        runId: activeRunId,
        processedUnits: processedPairs,
        totalUnits: totalPairs,
        progressUnit: runtimeUnit
    });
}

function startLoadingProgress(estimatedPairs, estimatedDurationMs, statusText = 'Parsing chat...', enableTicker = true) {
    if (!loadingPanelEl) {
        return;
    }

    clearLoadingTicker();

    loadingPanelEl.classList.remove('hidden');
    loadingPanelEl.style.display = 'block';
    const startedAt = Date.now();

    setLoadingProgress(0, statusText, estimatedDurationMs, estimatedPairs);

    if (!enableTicker) {
        return;
    }

    loadingIntervalId = setInterval(() => {
        const elapsedMs = Date.now() - startedAt;
        const progress = clamp((elapsedMs / estimatedDurationMs) * 100, 0, 95);
        const remainingMs = Math.max(0, estimatedDurationMs - elapsedMs);
        setLoadingProgress(progress, statusText, remainingMs, estimatedPairs);
    }, 200);
}

function startStage2CountdownTicker() {
    if (!loadingPanelEl || activeStage2EstimatedDurationMs <= 0 || stage2StartedAtMs <= 0) {
        return;
    }

    clearLoadingTicker();

    loadingIntervalId = setInterval(() => {
        if (!activeRunId || activeStage2EstimatedDurationMs <= 0 || stage2StartedAtMs <= 0) {
            return;
        }

        const currentPercent = getCurrentLoadingPercent();
        const statusText = loadingStatusEl && loadingStatusEl.textContent
            ? loadingStatusEl.textContent
            : 'Stage 2/2: Parsing chat...';
        const elapsedMs = Date.now() - stage2StartedAtMs;
        const etaMs = currentPercent >= 99.5
            ? 0
            : Math.max(0, activeStage2EstimatedDurationMs - elapsedMs);

        setLoadingProgress(currentPercent, statusText, etaMs, 0);
    }, 1000);
}

function forceHideLoadingPanel() {
    if (!loadingPanelEl) {
        return;
    }

    clearLoadingTicker();
    loadingPanelEl.classList.remove('hidden');
    loadingPanelEl.style.display = 'block';
    setLoadingProgress(0, 'Waiting for action', 0, 0);
}

function stopLoadingProgress(success) {
    if (!loadingPanelEl) {
        return;
    }

    clearLoadingTicker();

    if (success) {
        setLoadingProgress(100, 'Done', 0, 0);
    } else {
        const currentPercent = Number.parseFloat(((loadingPercentEl && loadingPercentEl.textContent) || '0').replace('%', ''));
        const safePercent = Number.isFinite(currentPercent) ? currentPercent : 0;
        setLoadingProgress(safePercent, 'Stopped (with error)', 0, 0);
    }
}

function persistMessages(messages, meta) {
    const scrapeMode = sanitizeScrapeMode(meta && meta.scrapeMode);
    const pairLimit = getTailModeLimit(scrapeMode);
    const limitedMessages = applyScrapeModeToMessages(messages, scrapeMode);
    const currentPairs = countStoredPairs(limitedMessages);
    let estimatedTotalPairs = getSafePairCount(meta && meta.estimatedTotalPairs);
    if (estimatedTotalPairs === 0 && (!meta || meta.progressUnit !== 'messages')) {
        estimatedTotalPairs = getSafePairCount(meta && meta.totalUnits);
    }
    estimatedTotalPairs = Math.min(pairLimit, Math.max(currentPairs, estimatedTotalPairs));

    const payload = {
        version: STORAGE_VERSION,
        savedAt: new Date().toISOString(),
        source: meta && meta.source ? meta.source : 'unknown',
        url: meta && meta.url ? meta.url : '',
        title: meta && meta.title ? meta.title : '',
        scrapeMode,
        checkpoint: Boolean(meta && meta.checkpoint),
        complete: Boolean(meta && meta.complete),
        runId: meta && typeof meta.runId === 'string' ? meta.runId : '',
        stage: meta && typeof meta.stage === 'string' ? meta.stage : '',
        processedUnits: Math.min(
            pairLimit,
            Math.max(0, Number.isFinite(meta && meta.processedUnits) ? Math.floor(meta.processedUnits) : 0)
        ),
        totalUnits: Math.min(
            pairLimit,
            Math.max(0, Number.isFinite(meta && meta.totalUnits) ? Math.floor(meta.totalUnits) : 0)
        ),
        progressUnit: meta && meta.progressUnit === 'messages' ? 'messages' : 'pairs',
        currentPairs,
        estimatedTotalPairs,
        messages: limitedMessages
    };

    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
        return true;
    } catch (error) {
        console.warn('Failed to persist chat history:', error);
        return false;
    }
}

function parseLegacyTranscript(text) {
    if (!text || typeof text !== 'string') {
        return [];
    }

    const lines = text.split('\n');
    const messages = [];
    let currentRole = null;
    let buffer = [];

    function flushCurrentMessage() {
        if (!currentRole) {
            buffer = [];
            return;
        }

        const textContent = normalizeText(buffer.join('\n'));
        if (textContent) {
            messages.push({
                role: currentRole,
                text: textContent
            });
        }

        buffer = [];
    }

    const assistantPrefixPattern = /^(ChatGPT|Assistant|GPT[\s-]?\d(?:\.\d+)?)/i;

    lines.forEach((line) => {
        const trimmed = line.trim();
        const startsUserBlock = /^(You|User)\b:?/i.test(trimmed);
        const startsAssistantBlock = assistantPrefixPattern.test(trimmed);

        if (startsUserBlock) {
            flushCurrentMessage();
            currentRole = 'user';
            const withoutPrefix = trimmed.replace(/^(You|User)\b:?\s*/i, '');
            if (withoutPrefix) {
                buffer.push(withoutPrefix);
            }
            return;
        }

        if (startsAssistantBlock) {
            flushCurrentMessage();
            currentRole = 'assistant';
            const withoutPrefix = trimmed.replace(assistantPrefixPattern, '').replace(/^:?\s*/, '');
            if (withoutPrefix) {
                buffer.push(withoutPrefix);
            }
            return;
        }

        if (currentRole) {
            buffer.push(line);
        }
    });

    flushCurrentMessage();
    return messages;
}

function parseStoredPayload(raw) {
    if (!raw) {
        return null;
    }

    try {
        const parsed = JSON.parse(raw);

        if (typeof parsed === 'string') {
            return {
                version: STORAGE_VERSION,
                savedAt: '',
                source: 'legacy-string',
                scrapeMode: SCRAPE_MODE_LAST_10_PAIRS,
                messages: applyScrapeModeToMessages(parseLegacyTranscript(parsed), SCRAPE_MODE_LAST_10_PAIRS)
            };
        }

        if (parsed && Array.isArray(parsed.messages)) {
            const scrapeMode = sanitizeScrapeMode(parsed.scrapeMode);
            return Object.assign({}, parsed, {
                scrapeMode,
                messages: applyScrapeModeToMessages(parsed.messages, scrapeMode)
            });
        }
    } catch (error) {
        return {
            version: STORAGE_VERSION,
            savedAt: '',
            source: 'legacy-transcript',
            scrapeMode: SCRAPE_MODE_LAST_10_PAIRS,
            messages: applyScrapeModeToMessages(parseLegacyTranscript(raw), SCRAPE_MODE_LAST_10_PAIRS)
        };
    }

    const legacyMessages = parseLegacyTranscript(raw);
    return legacyMessages.length > 0
        ? {
            version: STORAGE_VERSION,
            savedAt: '',
            source: 'legacy-transcript',
            scrapeMode: SCRAPE_MODE_LAST_10_PAIRS,
            messages: applyScrapeModeToMessages(legacyMessages, SCRAPE_MODE_LAST_10_PAIRS)
        }
        : null;
}

function readStoredPayload() {
    return parseStoredPayload(localStorage.getItem(STORAGE_KEY));
}

function readStoredMessages() {
    const payload = readStoredPayload();
    return payload && Array.isArray(payload.messages) ? payload.messages : [];
}

function getPayloadSavedAtMs(payload) {
    if (!payload || typeof payload.savedAt !== 'string') {
        return 0;
    }

    const savedAtMs = Date.parse(payload.savedAt);
    return Number.isFinite(savedAtMs) ? savedAtMs : 0;
}

function getPayloadMessageCount(payload) {
    return payload && Array.isArray(payload.messages) ? payload.messages.length : 0;
}

function shouldImportStoredPayload(candidatePayload, currentPayload) {
    if (!candidatePayload) {
        return false;
    }

    const candidateStage = typeof candidatePayload.stage === 'string' ? candidatePayload.stage : '';
    const candidateHasMessages = Array.isArray(candidatePayload.messages) && candidatePayload.messages.length > 0;
    const candidateHasActiveStage = candidateStage === 'stage1' || candidateStage === 'stage2';
    if (!candidateHasMessages && !candidateHasActiveStage) {
        return false;
    }

    if (!currentPayload) {
        return true;
    }

    const candidateSavedAtMs = getPayloadSavedAtMs(candidatePayload);
    const currentSavedAtMs = getPayloadSavedAtMs(currentPayload);
    const candidateRunId = typeof candidatePayload.runId === 'string' ? candidatePayload.runId : '';
    const currentRunId = typeof currentPayload.runId === 'string' ? currentPayload.runId : '';
    if (
        candidateRunId
        && candidateRunId !== currentRunId
        && candidateSavedAtMs > 0
        && candidateSavedAtMs > currentSavedAtMs
    ) {
        return true;
    }

    if (
        candidateHasActiveStage
        && candidateRunId
        && candidateRunId === currentRunId
        && candidateSavedAtMs > currentSavedAtMs
    ) {
        return true;
    }

    if (!candidateHasMessages) {
        return false;
    }

    if (!Array.isArray(currentPayload.messages) || currentPayload.messages.length === 0) {
        return true;
    }

    const candidatePairs = getStoredProgressState(candidatePayload).currentPairs;
    const currentPairs = getStoredProgressState(currentPayload).currentPairs;
    if (candidatePairs !== currentPairs) {
        return candidatePairs > currentPairs;
    }

    if (candidateSavedAtMs > 0 && currentSavedAtMs > 0 && candidateSavedAtMs > currentSavedAtMs) {
        return true;
    }

    return getPayloadMessageCount(candidatePayload) > getPayloadMessageCount(currentPayload);
}

function getSafeStorageMessages(messages) {
    if (!Array.isArray(messages)) {
        return [];
    }

    return messages
        .filter((message) => message && typeof message.role === 'string' && typeof message.text === 'string')
        .map((message) => ({
            role: message.role,
            text: normalizeText(message.text),
            id: typeof message.id === 'string' ? message.id : '',
            order: Number.isFinite(message.order) ? message.order : null
        }))
        .filter((message) => message.text.length > 0);
}

function persistProgressCheckpoint(messages, meta = {}, force = false) {
    const processedUnits = Math.max(0, Math.floor(Number.isFinite(meta.processedUnits) ? meta.processedUnits : 0));
    if (!force) {
        const previousBucket = Math.floor(lastPersistedProgressCheckpointUnits / CHECKPOINT_EVERY_UNITS);
        const nextBucket = Math.floor(processedUnits / CHECKPOINT_EVERY_UNITS);
        if (processedUnits < CHECKPOINT_EVERY_UNITS || nextBucket <= previousBucket) {
            return false;
        }
    }

    const safeMessages = getSafeStorageMessages(messages);
    if (safeMessages.length === 0) {
        return false;
    }

    const didPersist = persistMessages(safeMessages, Object.assign({}, meta, {
        source: meta.source || 'popup-progress-checkpoint',
        checkpoint: !force,
        complete: Boolean(meta.complete)
    }));

    if (didPersist) {
        lastPersistedProgressCheckpointUnits = processedUnits;
    }

    return didPersist;
}

function copyTextToClipboard(text) {
    return navigator.clipboard.writeText(text).catch((error) => {
        console.error('Unable to copy text to clipboard:', error);
    });
}

function getActiveTab() {
    return new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
            }

            const activeTab = tabs && tabs.length > 0 ? tabs[0] : null;
            if (!activeTab || !activeTab.id) {
                reject(new Error('Active tab is not available.'));
                return;
            }

            resolve(activeTab);
        });
    });
}

function executeExtractionScript(tabId, options = {}) {
    const args = Array.isArray(options.args) ? options.args : [];

    return new Promise((resolve, reject) => {
        chrome.scripting.executeScript(
            {
                target: { tabId },
                func: extractChatMessagesFromPage,
                args
            },
            (results) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }

                if (!results || results.length === 0) {
                    reject(new Error('No result returned by the page extraction script.'));
                    return;
                }

                resolve(results[0].result);
            }
        );
    });
}

function executeReadPageStorageScript(tabId) {
    return new Promise((resolve) => {
        chrome.scripting.executeScript(
            {
                target: { tabId },
                func: (storageKey) => {
                    try {
                        return localStorage.getItem(storageKey) || '';
                    } catch (error) {
                        return '';
                    }
                },
                args: [STORAGE_KEY]
            },
            (results) => {
                if (chrome.runtime.lastError || !results || results.length === 0) {
                    resolve('');
                    return;
                }

                resolve(typeof results[0].result === 'string' ? results[0].result : '');
            }
        );
    });
}

function executeClearPageStorageScript(tabId) {
    return new Promise((resolve) => {
        chrome.scripting.executeScript(
            {
                target: { tabId },
                func: (storageKey) => {
                    try {
                        localStorage.removeItem(storageKey);
                        return true;
                    } catch (error) {
                        return false;
                    }
                },
                args: [STORAGE_KEY]
            },
            () => {
                resolve(!chrome.runtime.lastError);
            }
        );
    });
}

async function clearPageCheckpointFromActiveTab() {
    try {
        const activeTab = await getActiveTab();
        if (activeTab && Number.isInteger(activeTab.id)) {
            await executeClearPageStorageScript(activeTab.id);
        }
    } catch (error) {
        // The active tab may be a restricted Chrome page; local popup history is still cleared.
    }
}

async function recoverPageCheckpointIfBetter() {
    if (activeRunId || pageCheckpointRefreshInFlight) {
        return false;
    }

    pageCheckpointRefreshInFlight = true;

    try {
        const activeTab = await getActiveTab();
        if (!activeTab || !Number.isInteger(activeTab.id)) {
            return false;
        }

        const rawPagePayload = await executeReadPageStorageScript(activeTab.id);
        const pagePayload = parseStoredPayload(rawPagePayload);
        const currentPayload = readStoredPayload();
        if (!shouldImportStoredPayload(pagePayload, currentPayload)) {
            return false;
        }

        const pageStage = typeof pagePayload.stage === 'string' ? pagePayload.stage : '';
        const pageMessages = Array.isArray(pagePayload.messages) ? pagePayload.messages : [];
        if ((pageStage === 'stage1' || pageStage === 'stage2') && pageMessages.length === 0) {
            const mode = sanitizeScrapeMode(pagePayload.scrapeMode);
            persistMessages([], Object.assign({}, pagePayload, { scrapeMode: mode }));
            clearColumns();
            restoreProgressFromStoredPayload(Object.assign({}, pagePayload, { scrapeMode: mode }));
            return true;
        }

        const mode = sanitizeScrapeMode(pagePayload.scrapeMode || getSelectedScrapeMode());
        const messages = applyScrapeModeToMessages(pagePayload.messages, mode);
        if (messages.length === 0) {
            return false;
        }

        persistMessages(messages, Object.assign({}, pagePayload, {
            source: pagePayload.source || 'page-localstorage-checkpoint',
            checkpoint: Boolean(pagePayload.checkpoint),
            complete: Boolean(pagePayload.complete)
        }));

        const { questions, answers } = buildColumnsFromMessages(messages, mode);
        renderColumns(questions, answers, mode);
        restoreProgressFromStoredPayload(Object.assign({}, pagePayload, {
            messages
        }));
        return true;
    } catch (error) {
        // Recovery is best-effort and must not block popup startup.
        return false;
    } finally {
        pageCheckpointRefreshInFlight = false;
    }
}

function startPageCheckpointRefresh() {
    if (pageCheckpointRefreshIntervalId) {
        clearInterval(pageCheckpointRefreshIntervalId);
    }

    recoverPageCheckpointIfBetter();
    pageCheckpointRefreshIntervalId = setInterval(() => {
        recoverPageCheckpointIfBetter();
    }, 1000);
}

function stopPageCheckpointRefresh() {
    if (!pageCheckpointRefreshIntervalId) {
        return;
    }

    clearInterval(pageCheckpointRefreshIntervalId);
    pageCheckpointRefreshIntervalId = null;
}

async function countPairsOnPageProbe(options) {
    const progressMessageType = 'chatgpt_session_saver_progress';
    const cancelAttr = 'data-chatgpt-session-saver-cancel-run-id';
    const imageOnlyQuestionPlaceholder = '[Image-only question]';
    const safeOptions = options && typeof options === 'object' ? options : {};
    const runId = typeof safeOptions.runId === 'string' ? safeOptions.runId : '';

    function clampLocal(value, minValue, maxValue) {
        return Math.max(minValue, Math.min(maxValue, value));
    }

    function reportStage1Progress(progressPercent, etaMs) {
        if (isRunCancelled()) {
            return;
        }

        if (!runId || typeof chrome === 'undefined' || !chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') {
            return;
        }

        try {
            chrome.runtime.sendMessage({
                type: progressMessageType,
                runId,
                stage: 'stage1',
                progressPercent: clampLocal(progressPercent, 0, 100),
                etaMs: Number.isFinite(etaMs) ? Math.max(0, etaMs) : 0
            }, () => {
                void chrome.runtime.lastError;
            });
        } catch (error) {
            // Ignore progress messaging errors.
        }
    }

    function isRunCancelled() {
        if (!runId) {
            return false;
        }

        return document.documentElement.getAttribute(cancelAttr) === runId;
    }

    function normalizeProbeText(text) {
        if (!text) {
            return '';
        }

        return text
            .replace(/\u00A0/g, ' ')
            .replace(/\r/g, '')
            .replace(/[ \t]+\n/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    }

    function hasRichMediaContent(node) {
        if (!node) {
            return false;
        }

        const mediaNodes = node.querySelectorAll(
            'img[src], picture img[src], video, canvas, [data-testid*="image"], [data-testid*="attachment"], [aria-label*="image" i], [aria-label*="photo" i], [style*="background-image"], a[href^="blob:"], a[href*="oaidalle"], a[href*="openai"]'
        );

        for (const mediaNode of mediaNodes) {
            if (!(mediaNode instanceof Element)) {
                continue;
            }

            const tagName = mediaNode.tagName.toLowerCase();
            if (tagName === 'img') {
                const src = mediaNode.getAttribute('src') || '';
                if (!src || src.startsWith('data:image/svg+xml')) {
                    continue;
                }

                const width = Number(mediaNode.getAttribute('width')) || mediaNode.clientWidth || mediaNode.naturalWidth || 0;
                const height = Number(mediaNode.getAttribute('height')) || mediaNode.clientHeight || mediaNode.naturalHeight || 0;
                if (width >= 32 || height >= 32 || (!width && !height)) {
                    return true;
                }
                continue;
            }

            return true;
        }

        return false;
    }

    function delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    function isProbeNodeHidden(node) {
        if (!node || node.getAttribute('aria-hidden') === 'true' || node.hidden) {
            return true;
        }

        const style = window.getComputedStyle(node);
        return style.display === 'none' || style.visibility === 'hidden';
    }

    function isScrollableElement(element) {
        if (!element || !(element instanceof Element)) {
            return false;
        }

        const style = window.getComputedStyle(element);
        const overflowY = style.overflowY;
        const canScrollByStyle = overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay';
        return canScrollByStyle && element.scrollHeight > element.clientHeight + 200;
    }

    function findScrollParent(element) {
        let cursor = element;

        while (cursor && cursor.parentElement) {
            cursor = cursor.parentElement;
            if (isScrollableElement(cursor)) {
                return cursor;
            }
        }

        return null;
    }

    function getConversationScrollContainer() {
        const firstMessageNode = document.querySelector(
            '[data-message-author-role="user"], [data-message-author-role="assistant"]'
        );

        if (firstMessageNode) {
            const parentScroller = findScrollParent(firstMessageNode);
            if (parentScroller) {
                return parentScroller;
            }
        }

        const mainElement = document.querySelector('main');
        if (isScrollableElement(mainElement)) {
            return mainElement;
        }

        return document.scrollingElement || document.documentElement;
    }

    function getScrollTop(scroller) {
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
        }

        return scroller.scrollTop;
    }

    function setScrollTop(scroller, value) {
        const target = Math.max(0, value);
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            window.scrollTo(0, target);
            return;
        }

        scroller.scrollTop = target;
    }

    function getMaxScrollTop(scroller) {
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            const root = document.scrollingElement || document.documentElement;
            return Math.max(0, root.scrollHeight - window.innerHeight);
        }

        return Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    }

    function getStepSize(scroller) {
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            return Math.max(180, Math.floor(window.innerHeight * 0.45));
        }

        return Math.max(180, Math.floor(scroller.clientHeight * 0.45));
    }

    const scroller = getConversationScrollContainer();
    const originalTop = getScrollTop(scroller);
    const seen = new Set();
    const stage1StartedAtMs = Date.now();

    function collectVisibleUsers() {
        const userNodes = Array.from(
            document.querySelectorAll(
                '[data-message-author-role="user"], [data-turn="user"], article[data-turn="user"], section[data-turn="user"]'
            )
        );

        userNodes.forEach((node, index) => {
            if (isProbeNodeHidden(node)) {
                return;
            }

            const text = normalizeProbeText(node.innerText || node.textContent || '');
            const finalText = text || (hasRichMediaContent(node) ? imageOnlyQuestionPlaceholder : '');
            if (!finalText) {
                return;
            }

            const nodeId = node.getAttribute('data-message-id')
                || node.getAttribute('data-turn-id')
                || node.getAttribute('data-testid')
                || `idx-${index}`;
            const key = `${nodeId}:${finalText.length}:${finalText.slice(0, 220)}:${finalText.slice(-120)}`;
            seen.add(key);
        });
    }

    collectVisibleUsers();

    const step = getStepSize(scroller);
    setScrollTop(scroller, getMaxScrollTop(scroller));
    await delay(160);
    collectVisibleUsers();
    const scanStartTop = getScrollTop(scroller);

    reportStage1Progress(0, 0);

    let noProgressSteps = 0;

    for (;;) {
        if (isRunCancelled()) {
            setScrollTop(scroller, originalTop);
            return { count: seen.size, cancelled: true };
        }

        const beforeTop = getScrollTop(scroller);
        if (beforeTop <= 0) {
            break;
        }

        const beforeCount = seen.size;
        setScrollTop(scroller, beforeTop - step);
        await delay(90);
        collectVisibleUsers();

        const afterTop = getScrollTop(scroller);
        const moved = Math.abs(afterTop - beforeTop) >= 1;
        const grew = seen.size > beforeCount;

        if (!moved && !grew) {
            noProgressSteps += 1;
        } else {
            noProgressSteps = 0;
        }

        if (noProgressSteps >= 35) {
            break;
        }

        const elapsedMs = Date.now() - stage1StartedAtMs;
        const progressPercent = scanStartTop > 0
            ? clampLocal(((scanStartTop - afterTop) / scanStartTop) * 100, 0, 100)
            : 100;
        const etaMs = progressPercent > 0
            ? (elapsedMs * (100 - progressPercent)) / progressPercent
            : 0;
        reportStage1Progress(progressPercent, etaMs);
    }

    setScrollTop(scroller, originalTop);
    if (isRunCancelled()) {
        return { count: seen.size, cancelled: true };
    }

    reportStage1Progress(100, 0);
    return { count: seen.size, cancelled: false };
}

function executePairCountProbe(tabId, options = {}) {
    const args = Array.isArray(options.args) ? options.args : [];

    return new Promise((resolve, reject) => {
        chrome.scripting.executeScript(
            {
                target: { tabId },
                func: countPairsOnPageProbe,
                args
            },
            (results) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }

                const value = results && results[0] ? results[0].result : 0;
                if (value && typeof value === 'object') {
                    const safeCount = Number.isFinite(value.count) ? Math.max(0, Math.floor(value.count)) : 0;
                    resolve({
                        count: safeCount,
                        cancelled: value.cancelled === true
                    });
                    return;
                }

                const safeCount = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
                resolve({
                    count: safeCount,
                    cancelled: false
                });
            }
        );
    });
}

function estimatePairsFromStoredData() {
    const storedMessages = readStoredMessages();
    const { questions } = splitMessagesByRole(storedMessages);
    return questions.length;
}

function setSaveButtonState(isLoading) {
    saveButtonEl.disabled = isLoading;
    saveButtonEl.textContent = isLoading ? 'Saving...' : 'Save Chat Session';
}

function setStopButtonState(isRunning, isStopping = false) {
    if (!stopButtonEl) {
        return;
    }

    stopButtonEl.classList.toggle('btnHidden', !isRunning);
    stopButtonEl.disabled = !isRunning || isStopping;
    stopButtonEl.textContent = isStopping ? 'Stopping...' : 'Stop Script';
}

function setScrapeModeControlState(isLocked) {
    if (!scrapeModeSelectEl) {
        return;
    }

    scrapeModeSelectEl.disabled = isLocked;
}

function getCurrentLoadingPercent() {
    const raw = ((loadingPercentEl && loadingPercentEl.textContent) || '0').replace('%', '');
    const value = Number.parseFloat(raw);
    return Number.isFinite(value) ? clamp(value, 0, 100) : 0;
}

function setRunCancelMarker(tabId, runId) {
    return new Promise((resolve, reject) => {
        chrome.scripting.executeScript(
            {
                target: { tabId },
                func: (attributeName, attributeValue) => {
                    const value = typeof attributeValue === 'string' ? attributeValue : '';
                    document.documentElement.setAttribute(attributeName, value);
                    return true;
                },
                args: [RUN_CANCEL_ATTR, runId || '']
            },
            () => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }

                resolve(true);
            }
        );
    });
}

async function requestStopCurrentRun() {
    if (stopInProgress) {
        return;
    }

    if (!activeRunId || !Number.isInteger(activeRunTabId)) {
        return;
    }

    stopRequested = true;
    stopInProgress = true;
    setStopButtonState(true, true);
    setLoadingProgress(getCurrentLoadingPercent(), 'Stopping script...', 0, activeTotalPairs);

    try {
        await setRunCancelMarker(activeRunTabId, activeRunId);
    } catch (error) {
        console.warn('Failed to request stop on tab:', error);
    }
}

async function saveAndProcessChatSession() {
    const scrapeMode = getSelectedScrapeMode();
    const isTailMode = isTailLimitedMode(scrapeMode);
    const tailLimit = getTailModeLimit(scrapeMode);

    setSaveButtonState(true);
    setStopButtonState(true, false);
    setScrapeModeControlState(true);
    clearUiForNewRun();
    activeScrapeMode = scrapeMode;
    activeProgressUnit = 'pairs';

    let loadingStarted = false;
    let estimatedDurationMs = 20000;
    let estimatedPairs = 0;
    activeRunId = `run-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    activeRunTabId = null;
    activeTotalPairs = 0;
    activeApproxPairEstimate = 0;
    activeStage2EstimatedDurationMs = 0;
    lastPersistedProgressCheckpointUnits = 0;
    stopRequested = false;
    stopInProgress = false;

    try {
        const stage1InitialStatus = isTailMode
            ? 'Stage 1/2: Preparing bottom scan...'
            : 'Stage 1/2: Loading full history...';
        startLoadingProgress(0, estimatedDurationMs, stage1InitialStatus, false);
        loadingStarted = true;

        const activeTab = await getActiveTab();
        activeRunTabId = activeTab.id;
        await executeClearPageStorageScript(activeTab.id);

        const shouldRunStage1Probe = false;
        if (isTailMode && tailLimit > 0) {
            estimatedPairs = tailLimit;
        }

        estimatedPairs = getSafePairCount(estimatedPairs);
        activeTotalPairs = estimatedPairs;
        activeApproxPairEstimate = estimatedPairs;
        estimatedDurationMs = isTailMode
            ? Math.max(8000, estimatedPairs * 3000)
            : estimateParseDurationMs(estimatedPairs);
        activeStage2EstimatedDurationMs = estimatedDurationMs;
        if (!shouldRunStage1Probe) {
            const stage1DoneStatus = 'Stage 1/2 skipped: tail mode starts from bottom';
            setLoadingProgress(100, stage1DoneStatus, estimatedDurationMs, estimatedPairs);
            clearLoadingTicker();
            const stage2InitLabel = estimatedPairs > 0 ? `0/${estimatedPairs}` : '0/?';
            setLoadingProgress(0, `Stage 2/2: ${stage2InitLabel} pairs`, estimatedDurationMs, estimatedPairs);
            stage2StartedAtMs = Date.now();
        }

        const extractionResult = await executeExtractionScript(activeTab.id, {
            args: [{
                runId: activeRunId,
                totalPairs: estimatedPairs,
                scrapeMode,
                runStage1Probe: shouldRunStage1Probe
            }]
        });
        if (stopRequested || (extractionResult && extractionResult.cancelled === true)) {
            setLoadingProgress(getCurrentLoadingPercent(), 'Stopped by user', 0, activeTotalPairs);
            return;
        }

        if (extractionResult && Number.isFinite(extractionResult.estimatedTotalPairs)) {
            estimatedPairs = Math.min(tailLimit, getSafePairCount(extractionResult.estimatedTotalPairs));
            activeTotalPairs = estimatedPairs;
            activeApproxPairEstimate = estimatedPairs;
            activeStage2EstimatedDurationMs = estimateParseDurationMs(estimatedPairs);
        }

        const extractedMessages = extractionResult && Array.isArray(extractionResult.messages)
            ? extractionResult.messages
            : [];
        const messages = applyScrapeModeToMessages(extractedMessages, scrapeMode);

        if (messages.length === 0) {
            throw new Error('No user/assistant messages found in the current tab.');
        }

        const { questions, answers } = buildColumnsFromMessages(messages, scrapeMode);
        renderColumns(questions, answers);
        persistMessages(messages, Object.assign({}, extractionResult, {
            scrapeMode,
            complete: true,
            processedUnits: activeProgressUnit === 'messages' ? messages.length : questions.length,
            totalUnits: activeProgressUnit === 'messages' ? messages.length : questions.length,
            progressUnit: activeProgressUnit,
            estimatedTotalPairs: activeTotalPairs
        }));
        if (loadingStarted) {
            const finalUnits = activeProgressUnit === 'messages' ? messages.length : questions.length;
            const finalTotal = activeTotalPairs > 0 ? activeTotalPairs : finalUnits;
            updateLivePairProgress(finalUnits, finalTotal, 100);
            stopLoadingProgress(true);
            const doneUnitLabel = activeProgressUnit === 'messages' ? 'messages' : 'pairs';
            const finalPercent = finalTotal > 0
                ? clamp((finalUnits / finalTotal) * 100, 0, 100)
                : 0;
            const finalStatus = finalUnits >= finalTotal ? 'Done' : 'Saved';
            const remainingUnits = Math.max(0, finalTotal - finalUnits);
            const finalEtaMs = clamp(remainingUnits * AVERAGE_PAIR_PARSE_MS, 0, MAX_PARSE_MS);
            setLoadingProgress(
                finalPercent,
                `${finalStatus}: ${finalUnits}/${finalTotal} ${doneUnitLabel}`,
                finalEtaMs,
                finalTotal
            );
            loadingStarted = false;
        }
    } catch (error) {
        console.error('Failed to save and parse session:', error);
        if (loadingStarted) {
            stopLoadingProgress(false);
            loadingStarted = false;
        }
        if (stopRequested) {
            setLoadingProgress(getCurrentLoadingPercent(), 'Stopped by user', 0, activeTotalPairs);
        } else {
            setLoadingProgress(0, 'Error: parsing failed. Retry Save Chat Session.', 0, activeTotalPairs);
        }
    } finally {
        if (loadingStarted) {
            stopLoadingProgress(false);
        }

        if (Number.isInteger(activeRunTabId)) {
            try {
                await setRunCancelMarker(activeRunTabId, '');
            } catch (clearCancelError) {
                console.warn('Failed to clear cancel marker in finally:', clearCancelError);
            }
        }

        activeRunId = '';
        activeRunTabId = null;
        activeTotalPairs = 0;
        activeApproxPairEstimate = 0;
        activeStage2EstimatedDurationMs = 0;
        lastPersistedProgressCheckpointUnits = 0;
        activeScrapeMode = SCRAPE_MODE_LAST_10_PAIRS;
        stopRequested = false;
        stopInProgress = false;
        resetLiveParseState();
        setSaveButtonState(false);
        setStopButtonState(false, false);
        setScrapeModeControlState(false);
    }
}

function loadChatHistory() {
    const payload = readStoredPayload();
    const mode = sanitizeScrapeMode(payload && payload.scrapeMode);
    const messages = applyScrapeModeToMessages(
        payload && Array.isArray(payload.messages) ? payload.messages : [],
        mode
    );
    if (messages.length === 0) {
        clearColumns();
        restoreProgressFromStoredPayload(payload);
        return;
    }

    activeScrapeMode = mode;
    if (scrapeModeSelectEl) {
        scrapeModeSelectEl.value = mode;
    }
    persistMessages(messages, Object.assign({}, payload, { scrapeMode: mode }));
    const { questions, answers } = splitMessagesByRole(messages);
    renderColumns(questions, answers, mode);
    restoreProgressFromStoredPayload(Object.assign({}, payload, {
        scrapeMode: mode,
        messages
    }));
}

function logPopupOverflowDiagnostics(stage = 'runtime') {
    try {
        console.log(`[popup-overflow:${stage}] root metrics`, {
            bodyScrollHeight: document.body.scrollHeight,
            bodyClientHeight: document.body.clientHeight,
            htmlScrollHeight: document.documentElement.scrollHeight,
            htmlClientHeight: document.documentElement.clientHeight
        });

        const appNode = document.querySelector('.app') || document.querySelector('.popupShell');
        if (appNode) {
            const appRect = appNode.getBoundingClientRect();
            console.log(`[popup-overflow:${stage}] app metrics`, {
                tag: appNode.tagName.toLowerCase(),
                className: appNode.className,
                scrollHeight: appNode.scrollHeight,
                clientHeight: appNode.clientHeight,
                rectHeight: appRect.height
            });
        }

        [...document.body.children].forEach((el) => {
            const rect = el.getBoundingClientRect();
            console.log(`[popup-overflow:${stage}] body child`, el, {
                scrollHeight: el.scrollHeight,
                clientHeight: el.clientHeight,
                rectHeight: rect.height,
                className: el.className
            });
        });

        [...document.querySelectorAll('body *')].forEach((el) => {
            if (el.scrollHeight > el.clientHeight + 2) {
                console.log('overflow element:', el, {
                    scrollHeight: el.scrollHeight,
                    clientHeight: el.clientHeight,
                    className: el.className
                });
            }
        });
    } catch (error) {
        console.warn('Popup overflow diagnostics failed:', error);
    }
}

async function extractChatMessagesFromPage(options) {
    const progressMessageType = 'chatgpt_session_saver_progress';
    const cancelAttr = 'data-chatgpt-session-saver-cancel-run-id';
    const imageOnlyQuestionPlaceholder = '[Image-only question]';
    const imageOnlyAnswerPlaceholder = '[Image-only answer]';
    const modeLast10Pairs = 'last_10_pairs';
    const modeLast20Pairs = 'last_20_pairs';
    const modeLast30Pairs = 'last_30_pairs';
    const allowedModes = new Set([
        modeLast10Pairs,
        modeLast20Pairs,
        modeLast30Pairs
    ]);
    const safeOptions = options && typeof options === 'object' ? options : {};
    const runId = typeof safeOptions.runId === 'string' ? safeOptions.runId : '';
    const rawScrapeMode = typeof safeOptions.scrapeMode === 'string' ? safeOptions.scrapeMode : modeLast10Pairs;
    const scrapeMode = allowedModes.has(rawScrapeMode) ? rawScrapeMode : modeLast10Pairs;
    const demoPairLimit = scrapeMode === modeLast20Pairs
        ? 20
        : (scrapeMode === modeLast30Pairs ? 30 : 10);
    const totalPairsHint = Number.isFinite(safeOptions.totalPairs) && safeOptions.totalPairs > 0
        ? Math.min(demoPairLimit, Math.floor(safeOptions.totalPairs))
        : 0;
    const shouldRunStage1Probe = false;
    const checkpointStorageKey = 'chatGPTHistoryDemo';
    const checkpointEveryUnits = 10;
    let lastPageCheckpointUnits = 0;
    let estimatedTotalPairs = totalPairsHint;
    let lastStage1PersistedAtMs = 0;

    function clampLocal(value, minValue, maxValue) {
        return Math.max(minValue, Math.min(maxValue, value));
    }

    function isRunCancelled() {
        if (!runId) {
            return false;
        }

        return document.documentElement.getAttribute(cancelAttr) === runId;
    }

    function sendProgressMessage(payload) {
        if (isRunCancelled()) {
            return;
        }

        if (!runId || typeof chrome === 'undefined' || !chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') {
            return;
        }

        const messagePayload = Object.assign({
            type: progressMessageType,
            runId
        }, payload || {});

        try {
            chrome.runtime.sendMessage(messagePayload, () => {
                void chrome.runtime.lastError;
            });
        } catch (error) {
            // Ignore messaging issues when popup is closed/reopened.
        }
    }

    function persistStageStatus(stage, progressPercent, etaMs, totalPairs = 0) {
        const now = Date.now();
        const safeProgressPercent = Number.isFinite(progressPercent)
            ? clampLocal(progressPercent, 0, 100)
            : 0;
        const shouldPersist = stage !== 'stage1'
            || safeProgressPercent === 0
            || safeProgressPercent === 100
            || now - lastStage1PersistedAtMs >= 500;
        if (!shouldPersist) {
            return;
        }

        const safeTotalPairs = Number.isFinite(totalPairs) && totalPairs > 0
            ? Math.min(demoPairLimit, Math.floor(totalPairs))
            : 0;
        const payload = {
            version: 3,
            savedAt: new Date(now).toISOString(),
            source: `page-${stage}-progress`,
            url: window.location.href,
            title: document.title,
            scrapeMode,
            checkpoint: true,
            complete: false,
            runId,
            stage,
            stage1ProgressPercent: stage === 'stage1' ? safeProgressPercent : 100,
            etaMs: Number.isFinite(etaMs) ? Math.max(0, etaMs) : 0,
            processedUnits: 0,
            totalUnits: safeTotalPairs,
            progressUnit: 'pairs',
            currentPairs: 0,
            estimatedTotalPairs: safeTotalPairs,
            messages: []
        };

        try {
            localStorage.setItem(checkpointStorageKey, JSON.stringify(payload));
            if (stage === 'stage1') {
                lastStage1PersistedAtMs = now;
            }
        } catch (error) {
            // Page checkpoint persistence is best-effort.
        }
    }

    function reportStage1Progress(progressPercent, etaMs) {
        const safeProgressPercent = Number.isFinite(progressPercent)
            ? clampLocal(progressPercent, 0, 100)
            : 0;
        const safeEtaMs = Number.isFinite(etaMs) ? Math.max(0, etaMs) : 0;
        persistStageStatus('stage1', safeProgressPercent, safeEtaMs, 0);
        sendProgressMessage({
            stage: 'stage1',
            progressPercent: safeProgressPercent,
            etaMs: safeEtaMs
        });
    }

    function reportStage2Progress(
        processedPairs,
        totalPairs,
        scrollProgressPercent,
        messagesChunk,
        progressUnit = 'pairs',
        fullMessages
    ) {
        if (isRunCancelled()) {
            return;
        }

        const safeProcessed = Math.min(
            demoPairLimit,
            Math.max(0, Math.floor(Number.isFinite(processedPairs) ? processedPairs : 0))
        );
        const safeTotal = Number.isFinite(totalPairs) && totalPairs > 0
            ? Math.min(demoPairLimit, Math.floor(totalPairs))
            : 0;
        const safeScrollProgress = Number.isFinite(scrollProgressPercent) ? clampLocal(scrollProgressPercent, 0, 100) : 0;
        const safeChunk = getStorageSafeMessages(messagesChunk);
        const safeFullMessages = Array.isArray(fullMessages)
            ? getStorageSafeMessages(fullMessages)
            : null;

        sendProgressMessage({
            stage: 'stage2',
            processedPairs: safeProcessed,
            totalPairs: safeTotal,
            processedUnits: safeProcessed,
            totalUnits: safeTotal,
            progressUnit: progressUnit === 'messages' ? 'messages' : 'pairs',
            scrollProgressPercent: safeScrollProgress,
            messagesChunk: safeChunk,
            fullMessages: safeFullMessages
        });
    }

    function normalize(text) {
        if (!text) {
            return '';
        }

        return text
            .replace(/\u00A0/g, ' ')
            .replace(/\r/g, '')
            .replace(/[ \t]+\n/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    }

    function getStorageSafeMessages(messages) {
        if (!Array.isArray(messages)) {
            return [];
        }

        const normalizedMessages = messages
            .filter((message) => message && typeof message.role === 'string' && typeof message.text === 'string')
            .map((message) => ({
                role: message.role,
                text: normalize(message.text),
                id: typeof message.id === 'string' ? message.id : '',
                order: Number.isFinite(message.order) ? message.order : null
            }))
            .filter((message) => message.text.length > 0);

        const collectedReverse = [];
        let userCount = 0;
        for (let index = normalizedMessages.length - 1; index >= 0; index -= 1) {
            const message = normalizedMessages[index];
            collectedReverse.push(message);
            if (message.role === 'user') {
                userCount += 1;
                if (userCount >= demoPairLimit) {
                    break;
                }
            }
        }

        return collectedReverse.reverse();
    }

    function persistPageCheckpoint(
        messages,
        processedUnits,
        totalUnits,
        scrollProgressPercent,
        progressUnit = 'pairs',
        force = false,
        complete = false
    ) {
        const safeProcessedUnits = Math.min(
            demoPairLimit,
            Math.max(0, Math.floor(Number.isFinite(processedUnits) ? processedUnits : 0))
        );
        if (!force) {
            const previousBucket = Math.floor(lastPageCheckpointUnits / checkpointEveryUnits);
            const nextBucket = Math.floor(safeProcessedUnits / checkpointEveryUnits);
            if (safeProcessedUnits < checkpointEveryUnits || nextBucket <= previousBucket) {
                return false;
            }
        }

        const safeMessages = getStorageSafeMessages(messages);
        if (safeMessages.length === 0) {
            return false;
        }

        const safeTotalUnits = Number.isFinite(totalUnits) && totalUnits > 0
            ? Math.min(demoPairLimit, Math.floor(totalUnits))
            : 0;
        const safeScrollProgress = Number.isFinite(scrollProgressPercent)
            ? clampLocal(scrollProgressPercent, 0, 100)
            : 0;
        const payload = {
            version: 3,
            savedAt: new Date().toISOString(),
            source: 'page-localstorage-checkpoint',
            url: window.location.href,
            title: document.title,
            scrapeMode,
            checkpoint: !complete,
            complete: Boolean(complete),
            runId,
            stage: 'stage2',
            processedUnits: safeProcessedUnits,
            totalUnits: safeTotalUnits,
            progressUnit: progressUnit === 'messages' ? 'messages' : 'pairs',
            currentPairs: getProcessedPairCount(safeMessages),
            estimatedTotalPairs: progressUnit === 'messages'
                ? (Number.isFinite(totalPairsHint) && totalPairsHint > 0 ? Math.floor(totalPairsHint) : 0)
                : safeTotalUnits,
            scrollProgressPercent: safeScrollProgress,
            messages: safeMessages
        };

        try {
            localStorage.setItem(checkpointStorageKey, JSON.stringify(payload));
            lastPageCheckpointUnits = safeProcessedUnits;
            return true;
        } catch (error) {
            return false;
        }
    }

    function getMessageText(node) {
        if (!node) {
            return '';
        }

        const clone = node.cloneNode(true);
        clone.querySelectorAll('button,svg,script,style,noscript,textarea').forEach((el) => el.remove());
        clone.querySelectorAll('.sr-only,[class*="screen-reader"]').forEach((el) => el.remove());

        return normalize(clone.innerText || clone.textContent || '');
    }

    function hasRichMediaContent(node) {
        if (!node) {
            return false;
        }

        const mediaNodes = node.querySelectorAll(
            'img[src], picture img[src], video, canvas, [data-testid*="image"], [data-testid*="attachment"], [aria-label*="image" i], [aria-label*="photo" i], [style*="background-image"], a[href^="blob:"], a[href*="oaidalle"], a[href*="openai"]'
        );

        for (const mediaNode of mediaNodes) {
            if (!(mediaNode instanceof Element)) {
                continue;
            }

            const tagName = mediaNode.tagName.toLowerCase();
            if (tagName === 'img') {
                const src = mediaNode.getAttribute('src') || '';
                if (!src || src.startsWith('data:image/svg+xml')) {
                    continue;
                }

                const width = Number(mediaNode.getAttribute('width')) || mediaNode.clientWidth || mediaNode.naturalWidth || 0;
                const height = Number(mediaNode.getAttribute('height')) || mediaNode.clientHeight || mediaNode.naturalHeight || 0;
                if (width >= 32 || height >= 32 || (!width && !height)) {
                    return true;
                }
                continue;
            }

            return true;
        }

        return false;
    }

    function getMessageTextOrMediaPlaceholder(node, role) {
        const text = getMessageText(node);
        if (text) {
            return text;
        }

        if (!hasRichMediaContent(node)) {
            return '';
        }

        if (role === 'user') {
            return imageOnlyQuestionPlaceholder;
        }

        if (role === 'assistant') {
            return imageOnlyAnswerPlaceholder;
        }

        return '';
    }

    function normalizeRole(rawRole) {
        if (!rawRole || typeof rawRole !== 'string') {
            return '';
        }

        const role = rawRole.toLowerCase();
        if (role === 'user' || role.includes('user')) {
            return 'user';
        }

        if (
            role === 'assistant'
            || role === 'tool'
            || role.includes('assistant')
            || role.includes('model')
            || role.includes('gpt')
            || role.includes('bot')
        ) {
            return 'assistant';
        }

        return '';
    }

    function getTurnContainer(node) {
        if (!node || !(node instanceof Element)) {
            return null;
        }

        return node.closest(
            'article[data-testid^="conversation-turn-"], section[data-testid^="conversation-turn-"], [data-testid^="conversation-turn-"]'
        );
    }

    function getFirstAttributeValue(node, attributeNames) {
        if (!node || !(node instanceof Element)) {
            return '';
        }

        for (const attributeName of attributeNames) {
            const value = node.getAttribute(attributeName);
            if (value) {
                return value;
            }
        }

        return '';
    }

    function getMessageId(node) {
        if (!node || !(node instanceof Element)) {
            return '';
        }

        const turnContainer = getTurnContainer(node);
        const turnId = getFirstAttributeValue(turnContainer, ['data-turn-id', 'data-message-id', 'data-testid']);
        if (turnId) {
            return turnId;
        }

        const directId = getFirstAttributeValue(node, ['data-turn-id', 'data-message-id', 'data-testid']);
        if (directId) {
            return directId;
        }

        const messageContainer = node.closest('[data-message-id], [data-turn-id]');
        return getFirstAttributeValue(messageContainer, ['data-turn-id', 'data-message-id']);
    }

    function parseConversationOrder(value) {
        if (typeof value !== 'string') {
            return null;
        }

        const trimmedValue = value.trim();
        const turnMatch = trimmedValue.match(/conversation-turn-(\d+)/i);
        if (turnMatch) {
            return Number.parseInt(turnMatch[1], 10);
        }

        if (/^\d+$/.test(trimmedValue)) {
            return Number.parseInt(trimmedValue, 10);
        }

        return null;
    }

    function getMessageOrder(node) {
        if (!node || !(node instanceof Element)) {
            return null;
        }

        const turnContainer = getTurnContainer(node);
        const orderCandidates = [
            getFirstAttributeValue(turnContainer, ['data-testid', 'data-turn-id', 'data-message-id', 'aria-posinset', 'data-index']),
            getFirstAttributeValue(node, ['data-testid', 'data-turn-id', 'data-message-id', 'aria-posinset', 'data-index'])
        ];

        for (const candidate of orderCandidates) {
            const order = parseConversationOrder(candidate);
            if (Number.isFinite(order)) {
                return order;
            }
        }

        return null;
    }

    function getSortableMessageOrder(message) {
        if (message && Number.isFinite(message.order)) {
            return message.order;
        }

        if (message && Number.isFinite(message.fallbackOrder)) {
            return message.fallbackOrder;
        }

        return 0;
    }

    function sortMessagesByConversationOrder(messages) {
        if (!Array.isArray(messages)) {
            return [];
        }

        return messages.slice().sort((leftMessage, rightMessage) => {
            const leftOrder = getSortableMessageOrder(leftMessage);
            const rightOrder = getSortableMessageOrder(rightMessage);
            if (leftOrder !== rightOrder) {
                return leftOrder - rightOrder;
            }

            const leftSequence = Number.isFinite(leftMessage && leftMessage.sequence) ? leftMessage.sequence : 0;
            const rightSequence = Number.isFinite(rightMessage && rightMessage.sequence) ? rightMessage.sequence : 0;
            return leftSequence - rightSequence;
        });
    }

    function isVisuallyHidden(node) {
        if (!node) {
            return true;
        }

        if (node.getAttribute('aria-hidden') === 'true' || node.hidden) {
            return true;
        }

        const style = window.getComputedStyle(node);
        return style.display === 'none' || style.visibility === 'hidden';
    }

    function buildMessageKey(role, messageId, text) {
        const normalizedText = normalize(text || '');
        const signatureHead = normalizedText.slice(0, 700);
        const signatureTail = normalizedText.slice(-260);
        const signature = `${normalizedText.length}:${signatureHead}:${signatureTail}`;
        const safeMessageId = typeof messageId === 'string' ? messageId.trim() : '';
        if (safeMessageId) {
            return `${role}:id:${safeMessageId}`;
        }

        return `${role}:text:${signature}`;
    }

    function extractByRoleAttribute() {
        const roleNodes = Array.from(
            document.querySelectorAll(
                '[data-message-author-role="user"], [data-message-author-role="assistant"], [data-message-author-role="tool"]'
            )
        );
        const messages = [];
        const seen = new Set();

        roleNodes.forEach((node) => {
            if (isVisuallyHidden(node)) {
                return;
            }

            const rawRole = node.getAttribute('data-message-author-role');
            const role = normalizeRole(rawRole);
            if (!role) {
                return;
            }

            const text = getMessageTextOrMediaPlaceholder(node, role);
            if (!text) {
                return;
            }

            const messageId = getMessageId(node);
            const dedupeKey = buildMessageKey(role, messageId, text);
            if (seen.has(dedupeKey)) {
                return;
            }

            seen.add(dedupeKey);
            messages.push({
                role,
                text,
                id: messageId,
                order: getMessageOrder(node)
            });
        });

        return sortMessagesByConversationOrder(messages);
    }

    function extractByTurnSections() {
        const turnNodes = Array.from(
            document.querySelectorAll(
                '[data-testid^="conversation-turn-"][data-turn], section[data-turn][data-testid^="conversation-turn-"], article[data-turn][data-testid^="conversation-turn-"]'
            )
        );
        const messages = [];
        const seen = new Set();

        turnNodes.forEach((turnNode) => {
            if (isVisuallyHidden(turnNode)) {
                return;
            }

            const role = normalizeRole(turnNode.getAttribute('data-turn'));
            if (!role) {
                return;
            }

            const text = getMessageTextOrMediaPlaceholder(turnNode, role);
            if (!text) {
                return;
            }

            const turnId = getMessageId(turnNode);

            const dedupeKey = buildMessageKey(role, turnId, text);
            if (seen.has(dedupeKey)) {
                return;
            }

            seen.add(dedupeKey);
            messages.push({
                role,
                text,
                id: turnId,
                order: getMessageOrder(turnNode)
            });
        });

        return sortMessagesByConversationOrder(messages);
    }

    function getRoleStats(messages) {
        let userCount = 0;
        let assistantCount = 0;

        messages.forEach((message) => {
            if (!message || !message.role) {
                return;
            }

            if (message.role === 'user') {
                userCount += 1;
            } else if (message.role === 'assistant') {
                assistantCount += 1;
            }
        });

        return { userCount, assistantCount };
    }

    function getProcessedPairCount(messages) {
        let pairCount = 0;
        let hasActiveQuestion = false;
        let hasAnswerForCurrent = false;

        messages.forEach((message) => {
            if (!message || typeof message.text !== 'string') {
                return;
            }

            const text = normalize(message.text);
            if (!text) {
                return;
            }

            if (message.role === 'user') {
                if (!hasActiveQuestion) {
                    pairCount += 1;
                    hasActiveQuestion = true;
                    hasAnswerForCurrent = false;
                    return;
                }

                if (!hasAnswerForCurrent) {
                    pairCount += 1;
                    hasAnswerForCurrent = false;
                    return;
                }

                pairCount += 1;
                hasAnswerForCurrent = false;
                return;
            }

            if (message.role === 'assistant' && hasActiveQuestion) {
                hasAnswerForCurrent = true;
            }
        });

        return pairCount;
    }

    function splitMessagesIntoPairs(messages) {
        const pairs = [];
        let currentPair = null;

        messages.forEach((message) => {
            if (!message || typeof message.text !== 'string') {
                return;
            }

            const text = normalize(message.text);
            if (!text) {
                return;
            }

            if (message.role === 'user') {
                if (!currentPair) {
                    currentPair = {
                        question: text,
                        answer: '',
                        hasAnswer: false
                    };
                    return;
                }

                pairs.push(currentPair);
                currentPair = {
                    question: text,
                    answer: '',
                    hasAnswer: false
                };
                return;
            }

            if (message.role === 'assistant' && currentPair) {
                if (!currentPair.answer) {
                    currentPair.answer = text;
                } else {
                    currentPair.answer = `${currentPair.answer}\n\n${text}`;
                }
                currentPair.hasAnswer = true;
            }
        });

        if (currentPair) {
            pairs.push(currentPair);
        }

        return pairs;
    }

    function getCompletedTailPairsState(messages, pairLimit) {
        const timelinePairs = splitMessagesIntoPairs(messages);
        const completedPairs = timelinePairs.filter((pair) => pair && pair.hasAnswer && pair.question && pair.answer);
        const limitedPairs = pairLimit > 0 ? completedPairs.slice(-pairLimit) : completedPairs;
        const previewMessages = [];

        limitedPairs.forEach((pair) => {
            previewMessages.push({
                role: 'user',
                text: pair.question
            });
            previewMessages.push({
                role: 'assistant',
                text: pair.answer
            });
        });

        return {
            completedPairCount: limitedPairs.length,
            previewMessages
        };
    }

    function getDistinctUserTurnEstimate() {
        const userNodes = Array.from(
            document.querySelectorAll(
                '[data-message-author-role="user"], [data-turn="user"], article[data-turn="user"], section[data-turn="user"]'
            )
        );
        const seen = new Set();

        userNodes.forEach((node, index) => {
            const nodeId = node.getAttribute('data-message-id')
                || node.getAttribute('data-turn-id')
                || node.getAttribute('data-testid')
                || `idx-${index}`;
            const text = getMessageText(node);
            seen.add(buildMessageKey('user', nodeId, text || nodeId));
        });

        return seen.size;
    }

    function isScrollableElement(element) {
        if (!element || !(element instanceof Element)) {
            return false;
        }

        const style = window.getComputedStyle(element);
        const overflowY = style.overflowY;
        const canScrollByStyle = overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay';
        return canScrollByStyle && element.scrollHeight > element.clientHeight + 200;
    }

    function findScrollParent(element) {
        let cursor = element;

        while (cursor && cursor.parentElement) {
            cursor = cursor.parentElement;
            if (isScrollableElement(cursor)) {
                return cursor;
            }
        }

        return null;
    }

    function getConversationScrollContainer() {
        const firstMessageNode = document.querySelector(
            '[data-message-author-role="user"], [data-message-author-role="assistant"]'
        );

        if (firstMessageNode) {
            const parentScroller = findScrollParent(firstMessageNode);
            if (parentScroller) {
                return parentScroller;
            }
        }

        const mainElement = document.querySelector('main');
        if (isScrollableElement(mainElement)) {
            return mainElement;
        }

        const pageScroller = document.scrollingElement || document.documentElement;
        return pageScroller;
    }

    function getScrollTop(scroller) {
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
        }

        return scroller.scrollTop;
    }

    function setScrollTop(scroller, value) {
        const target = Math.max(0, value);

        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            window.scrollTo(0, target);
            return;
        }

        scroller.scrollTop = target;
    }

    function getMaxScrollTop(scroller) {
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            const root = document.scrollingElement || document.documentElement;
            return Math.max(0, root.scrollHeight - window.innerHeight);
        }

        return Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    }

    function getStepSize(scroller) {
        if (scroller === window || scroller === document.body || scroller === document.documentElement || scroller === document.scrollingElement) {
            return Math.max(160, Math.floor(window.innerHeight * 0.38));
        }

        return Math.max(160, Math.floor(scroller.clientHeight * 0.38));
    }

    function delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async function preloadFullHistoryForStage1(scroller) {
        const seenUsers = new Set();
        const startedAtMs = Date.now();
        reportStage1Progress(0, 0);

        function collectVisibleUsers() {
            const snapshots = [
                extractByConversationArticles(),
                extractByTurnSections(),
                extractByRoleAttribute()
            ];

            snapshots.forEach((snapshot) => {
                snapshot.forEach((message) => {
                    if (!message || message.role !== 'user' || typeof message.text !== 'string') {
                        return;
                    }

                    const key = buildMessageKey('user', message.id || '', message.text);
                    if (key) {
                        seenUsers.add(key);
                    }
                });
            });
        }

        collectVisibleUsers();
        setScrollTop(scroller, getMaxScrollTop(scroller));
        await delay(180);
        collectVisibleUsers();

        const scanStartTop = getScrollTop(scroller);
        const step = getStepSize(scroller);
        let noProgressSteps = 0;

        for (;;) {
            if (isRunCancelled()) {
                return {
                    count: seenUsers.size,
                    cancelled: true
                };
            }

            const beforeTop = getScrollTop(scroller);
            if (beforeTop <= 0) {
                break;
            }

            const beforeCount = seenUsers.size;
            setScrollTop(scroller, Math.max(0, beforeTop - step));
            await delay(100);
            collectVisibleUsers();

            const afterTop = getScrollTop(scroller);
            const moved = Math.abs(afterTop - beforeTop) >= 1;
            const grew = seenUsers.size > beforeCount;
            noProgressSteps = !moved && !grew ? noProgressSteps + 1 : 0;
            if (noProgressSteps >= 35) {
                break;
            }

            const elapsedMs = Date.now() - startedAtMs;
            const progressPercent = scanStartTop > 0
                ? clampLocal(((scanStartTop - afterTop) / scanStartTop) * 100, 0, 100)
                : 100;
            const etaMs = progressPercent > 0
                ? (elapsedMs * (100 - progressPercent)) / progressPercent
                : 0;
            reportStage1Progress(progressPercent, etaMs);
        }

        collectVisibleUsers();
        setScrollTop(scroller, 0);
        reportStage1Progress(100, 0);
        return {
            count: seenUsers.size,
            cancelled: isRunCancelled()
        };
    }

    async function extractByRoleAttributeWithAutoScroll() {
        const scroller = getConversationScrollContainer();
        const isModeCurrentDown = false;
        const isModeCurrentUp = false;
        const isTailMode = true;
        const tailLimit = demoPairLimit;
        const progressUnit = 'pairs';

        if (shouldRunStage1Probe) {
            const stage1Result = await preloadFullHistoryForStage1(scroller);
            estimatedTotalPairs = Math.max(
                estimatedTotalPairs,
                Number.isFinite(stage1Result.count) ? Math.floor(stage1Result.count) : 0,
                getDistinctUserTurnEstimate()
            );
            if (stage1Result.cancelled) {
                return {
                    messages: [],
                    cancelled: true,
                    estimatedTotalPairs
                };
            }
        }

        const estimatedUsers = Math.max(getDistinctUserTurnEstimate(), estimatedTotalPairs);
        const totalProgressGoal = (isModeCurrentDown || isModeCurrentUp)
            ? 0
            : (isTailMode ? tailLimit : estimatedUsers);

        persistStageStatus('stage2', 0, 0, totalProgressGoal);
        reportStage2Progress(0, totalProgressGoal, 0, [], progressUnit, []);

        function getReportProcessedUnits(rawUnits) {
            const safeUnits = Math.max(0, Math.floor(Number.isFinite(rawUnits) ? rawUnits : 0));
            if (isTailMode && totalProgressGoal > 0) {
                return Math.min(safeUnits, totalProgressGoal);
            }

            return safeUnits;
        }

        function getScrollProgressPercent(targetScroller, startTop, direction) {
            const maxTop = getMaxScrollTop(targetScroller);
            if (maxTop <= 0) {
                return 100;
            }

            const currentTop = getScrollTop(targetScroller);
            if (direction === 'up') {
                if (startTop <= 0) {
                    return 100;
                }

                return clampLocal(((startTop - currentTop) / startTop) * 100, 0, 100);
            }

            if (direction === 'down') {
                const downwardDistance = maxTop - startTop;
                if (downwardDistance <= 0) {
                    return 100;
                }

                return clampLocal(((currentTop - startTop) / downwardDistance) * 100, 0, 100);
            }

            return clampLocal((currentTop / maxTop) * 100, 0, 100);
        }

        function limitTailMessages(messages) {
            if (!isTailMode || !Array.isArray(messages) || messages.length === 0 || tailLimit <= 0) {
                return Array.isArray(messages) ? messages : [];
            }

            const reverseCollected = [];
            let userCount = 0;
            for (let index = messages.length - 1; index >= 0; index -= 1) {
                const message = messages[index];
                if (!message || typeof message.role !== 'string' || typeof message.text !== 'string') {
                    continue;
                }

                reverseCollected.push(message);
                if (message.role === 'user') {
                    userCount += 1;
                    if (userCount >= tailLimit) {
                        break;
                    }
                }
            }

            return reverseCollected.reverse();
        }

        if (!scroller) {
            const articleSnapshot = extractByConversationArticles();
            const turnSnapshot = articleSnapshot.length > 0 ? articleSnapshot : extractByTurnSections();
            const singleSnapshot = turnSnapshot.length > 0 ? turnSnapshot : extractByRoleAttribute();
            const normalizedSnapshot = sortMessagesByConversationOrder(singleSnapshot).map(({ role, text, id, order }) => ({
                role,
                text,
                id: typeof id === 'string' ? id : '',
                order: Number.isFinite(order) ? order : null
            }));
            const tailState = isTailMode ? getCompletedTailPairsState(normalizedSnapshot, tailLimit) : null;
            const limitedSnapshot = isTailMode ? tailState.previewMessages : limitTailMessages(normalizedSnapshot);
            const processedPairs = isTailMode ? tailState.completedPairCount : getProcessedPairCount(limitedSnapshot);
            const processedUnitsRaw = progressUnit === 'messages' ? limitedSnapshot.length : processedPairs;
            const processedUnits = getReportProcessedUnits(processedUnitsRaw);
            persistPageCheckpoint(
                limitedSnapshot,
                processedUnits,
                totalProgressGoal,
                100,
                progressUnit,
                true,
                true
            );
            reportStage2Progress(
                processedUnits,
                totalProgressGoal,
                100,
                limitedSnapshot,
                progressUnit,
                limitedSnapshot
            );
            return {
                messages: limitedSnapshot,
                cancelled: isRunCancelled()
            };
        }

        const originalTop = getScrollTop(scroller);
        const seen = new Set();
        const collected = [];
        let nextAppendFallbackOrder = 0;
        let nextPrependFallbackOrder = 0;
        let nextCollectionSequence = 0;
        let lastTailState = {
            completedPairCount: 0,
            previewMessages: []
        };
        let progressStartTop = originalTop;
        let progressDirection = 'full';

        function getBestSnapshot() {
            const merged = [];
            const seenSnapshotKeys = new Set();
            const snapshots = [
                extractByConversationArticles(),
                extractByTurnSections(),
                extractByRoleAttribute()
            ];

            snapshots.forEach((snapshot) => {
                snapshot.forEach((message) => {
                    const key = buildMessageKey(message.role, message.id || '', message.text);
                    if (!key || seenSnapshotKeys.has(key)) {
                        return;
                    }

                    seenSnapshotKeys.add(key);
                    merged.push(message);
                });
            });

            return merged;
        }

        function assignFallbackOrders(messages, placement) {
            if (!Array.isArray(messages) || messages.length === 0) {
                return;
            }

            if (placement === 'prepend') {
                const baseFallbackOrder = nextPrependFallbackOrder - messages.length;
                messages.forEach((message, index) => {
                    message.fallbackOrder = baseFallbackOrder + index;
                    message.sequence = nextCollectionSequence;
                    nextCollectionSequence += 1;
                });
                nextPrependFallbackOrder = baseFallbackOrder;
                return;
            }

            messages.forEach((message) => {
                message.fallbackOrder = nextAppendFallbackOrder;
                message.sequence = nextCollectionSequence;
                nextAppendFallbackOrder += 1;
                nextCollectionSequence += 1;
            });
        }

        function collectSnapshot(placement = 'append', sendFullMessages = false) {
            const snapshot = getBestSnapshot();
            const newUniqueMessages = [];

            snapshot.forEach((message) => {
                const dedupeKey = buildMessageKey(message.role, message.id || '', message.text);
                if (seen.has(dedupeKey)) {
                    return;
                }

                seen.add(dedupeKey);
                newUniqueMessages.push({
                    role: message.role,
                    text: message.text,
                    id: message.id || '',
                    order: Number.isFinite(message.order) ? message.order : null
                });
            });

            if (newUniqueMessages.length > 0) {
                assignFallbackOrders(newUniqueMessages, placement);
                collected.push(...newUniqueMessages);
            }

            const orderedCollected = sortMessagesByConversationOrder(collected);
            const processedPairs = getProcessedPairCount(orderedCollected);
            const collectedForPreview = orderedCollected.map((message) => ({
                role: message.role,
                text: message.text,
                id: typeof message.id === 'string' ? message.id : '',
                order: Number.isFinite(message.order) ? message.order : null
            }));
            if (isTailMode && tailLimit > 0) {
                lastTailState = getCompletedTailPairsState(collectedForPreview, tailLimit);
            }

            const pairsForProgress = isTailMode ? lastTailState.completedPairCount : processedPairs;
            const processedUnitsRaw = progressUnit === 'messages' ? collected.length : pairsForProgress;
            const processedUnits = getReportProcessedUnits(processedUnitsRaw);
            const scrollProgressPercent = getScrollProgressPercent(scroller, progressStartTop, progressDirection);
            const chunk = sortMessagesByConversationOrder(newUniqueMessages).map((message) => ({
                role: message.role,
                text: message.text,
                id: typeof message.id === 'string' ? message.id : '',
                order: Number.isFinite(message.order) ? message.order : null
            }));
            const fullMessages = sendFullMessages
                ? (isTailMode ? lastTailState.previewMessages : collectedForPreview)
                : null;
            persistPageCheckpoint(
                isTailMode ? lastTailState.previewMessages : collectedForPreview,
                processedUnits,
                totalProgressGoal,
                scrollProgressPercent,
                progressUnit,
                false,
                false
            );

            reportStage2Progress(
                processedUnits,
                totalProgressGoal,
                scrollProgressPercent,
                chunk,
                progressUnit,
                fullMessages
            );
        }

        function reachedTailTarget() {
            if (!isTailMode || tailLimit <= 0) {
                return false;
            }

            const collectedForPreview = sortMessagesByConversationOrder(collected).map((message) => ({
                role: message.role,
                text: message.text,
                id: typeof message.id === 'string' ? message.id : '',
                order: Number.isFinite(message.order) ? message.order : null
            }));
            const tailState = getCompletedTailPairsState(collectedForPreview, tailLimit);
            return tailState.completedPairCount >= tailLimit;
        }

        const step = getStepSize(scroller);
        let noProgressSteps = 0;

        if (isTailMode) {
            setScrollTop(scroller, getMaxScrollTop(scroller));
            await delay(220);
            progressStartTop = getScrollTop(scroller);
            progressDirection = 'up';
            collectSnapshot('append', true);
            await delay(120);
            collectSnapshot('append', true);

            for (;;) {
                if (isRunCancelled() || reachedTailTarget()) {
                    break;
                }

                const beforeTop = getScrollTop(scroller);
                if (beforeTop <= 0) {
                    break;
                }

                const beforeCount = collected.length;
                setScrollTop(scroller, Math.max(0, beforeTop - step));
                await delay(180);
                collectSnapshot('prepend', true);
                await delay(120);
                collectSnapshot('prepend', true);

                const afterTop = getScrollTop(scroller);
                const moved = Math.abs(afterTop - beforeTop) >= 1;
                const grew = collected.length > beforeCount;

                if (!moved && !grew) {
                    noProgressSteps += 1;
                } else {
                    noProgressSteps = 0;
                }

                if (noProgressSteps >= 45) {
                    break;
                }
            }
        } else if (isModeCurrentUp) {
            progressStartTop = getScrollTop(scroller);
            progressDirection = 'up';
            collectSnapshot('append', true);
            await delay(120);
            collectSnapshot('append', true);

            for (;;) {
                if (isRunCancelled()) {
                    break;
                }

                const beforeTop = getScrollTop(scroller);
                if (beforeTop <= 0) {
                    break;
                }

                const beforeCount = collected.length;
                setScrollTop(scroller, Math.max(0, beforeTop - step));
                await delay(180);
                collectSnapshot('prepend', true);
                await delay(120);
                collectSnapshot('prepend', true);

                const afterTop = getScrollTop(scroller);
                const moved = Math.abs(afterTop - beforeTop) >= 1;
                const grew = collected.length > beforeCount;

                if (!moved && !grew) {
                    noProgressSteps += 1;
                } else {
                    noProgressSteps = 0;
                }

                if (noProgressSteps >= 45) {
                    break;
                }
            }
        } else if (isModeCurrentDown) {
            progressStartTop = getScrollTop(scroller);
            progressDirection = 'down';
            collectSnapshot('append', true);
            await delay(120);
            collectSnapshot('append', true);

            for (;;) {
                if (isRunCancelled()) {
                    break;
                }

                const beforeTop = getScrollTop(scroller);
                const maxTop = getMaxScrollTop(scroller);
                if (beforeTop >= maxTop) {
                    break;
                }

                const beforeCount = collected.length;
                setScrollTop(scroller, Math.min(maxTop, beforeTop + step));
                await delay(180);
                collectSnapshot('append', true);
                await delay(120);
                collectSnapshot('append', true);

                const afterTop = getScrollTop(scroller);
                const moved = Math.abs(afterTop - beforeTop) >= 1;
                const grew = collected.length > beforeCount;

                if (!moved && !grew) {
                    noProgressSteps += 1;
                } else {
                    noProgressSteps = 0;
                }

                if (noProgressSteps >= 45) {
                    break;
                }
            }
        } else {
            setScrollTop(scroller, 0);
            progressStartTop = 0;
            progressDirection = 'full';
            await delay(220);
            collectSnapshot('append', false);
            await delay(120);
            collectSnapshot('append', false);

            for (;;) {
                if (isRunCancelled()) {
                    break;
                }

                const beforeTop = getScrollTop(scroller);
                const maxTop = getMaxScrollTop(scroller);
                if (beforeTop >= maxTop) {
                    break;
                }

                const beforeCount = collected.length;
                setScrollTop(scroller, Math.min(maxTop, beforeTop + step));
                await delay(180);
                collectSnapshot('append', false);
                await delay(120);
                collectSnapshot('append', false);

                const afterTop = getScrollTop(scroller);
                const moved = Math.abs(afterTop - beforeTop) >= 1;
                const grew = collected.length > beforeCount;

                if (!moved && !grew) {
                    noProgressSteps += 1;
                } else {
                    noProgressSteps = 0;
                }

                if (noProgressSteps >= 45) {
                    break;
                }
            }
        }

        setScrollTop(scroller, originalTop);
        const finalMessagesRaw = sortMessagesByConversationOrder(collected).map(({ role, text, id, order }) => ({
            role,
            text,
            id: typeof id === 'string' ? id : '',
            order: Number.isFinite(order) ? order : null
        }));
        const finalTailState = isTailMode ? getCompletedTailPairsState(finalMessagesRaw, tailLimit) : null;
        const finalMessages = isTailMode ? finalTailState.previewMessages : limitTailMessages(finalMessagesRaw);
        const finalPairs = isTailMode ? finalTailState.completedPairCount : getProcessedPairCount(finalMessages);
        const finalUnitsRaw = progressUnit === 'messages' ? finalMessages.length : finalPairs;
        const finalUnits = getReportProcessedUnits(finalUnitsRaw);
        persistPageCheckpoint(
            finalMessages,
            finalUnits,
            totalProgressGoal,
            100,
            progressUnit,
            true,
            true
        );
        reportStage2Progress(
            finalUnits,
            totalProgressGoal,
            100,
            [],
            progressUnit,
            (isTailMode || isModeCurrentUp) ? finalMessages : null
        );
        return {
            messages: finalMessages,
            cancelled: isRunCancelled(),
            estimatedTotalPairs: totalProgressGoal
        };
    }

    function extractByConversationArticles() {
        const turnArticles = Array.from(document.querySelectorAll('article[data-testid^="conversation-turn-"]'));
        const messages = [];

        turnArticles.forEach((article) => {
            if (isVisuallyHidden(article)) {
                return;
            }

            let role = '';
            const roleNode = article.querySelector(
                '[data-message-author-role="user"], [data-message-author-role="assistant"], [data-message-author-role="tool"]'
            );
            if (roleNode) {
                role = normalizeRole(roleNode.getAttribute('data-message-author-role'));
            } else {
                role = normalizeRole(article.getAttribute('data-turn'));
            }

            if (!role) {
                return;
            }

            const text = getMessageTextOrMediaPlaceholder(article, role);
            if (!text) {
                return;
            }

            messages.push({
                role,
                text,
                id: getMessageId(article),
                order: getMessageOrder(article)
            });
        });

        return sortMessagesByConversationOrder(messages);
    }

    function extractFromMainTextFallback() {
        const root = document.querySelector('main') || document.body;
        const transcript = normalize(root.innerText || root.textContent || '');
        if (!transcript) {
            return [];
        }

        const lines = transcript.split('\n');
        const messages = [];
        let currentRole = null;
        let buffer = [];

        function flushMessage() {
            if (!currentRole) {
                buffer = [];
                return;
            }

            const text = normalize(buffer.join('\n'));
            if (text) {
                messages.push({ role: currentRole, text });
            }

            buffer = [];
        }

        lines.forEach((line) => {
            const trimmed = line.trim();
            const startsUser = /^(You|User)$/i.test(trimmed);
            const startsAssistant = /^(ChatGPT|Assistant|GPT[\s-]?\d.*)$/i.test(trimmed);

            if (startsUser) {
                flushMessage();
                currentRole = 'user';
                return;
            }

            if (startsAssistant) {
                flushMessage();
                currentRole = 'assistant';
                return;
            }

            if (currentRole) {
                buffer.push(line);
            }
        });

        flushMessage();
        return messages;
    }

    const byRoleAutoscrollResult = await extractByRoleAttributeWithAutoScroll();
    const byRoleAutoscrollMessages = byRoleAutoscrollResult && Array.isArray(byRoleAutoscrollResult.messages)
        ? byRoleAutoscrollResult.messages
        : [];
    if (byRoleAutoscrollMessages.length > 0) {
        return {
            source: 'data-message-author-role-autoscroll',
            url: window.location.href,
            title: document.title,
            messages: byRoleAutoscrollMessages,
            cancelled: byRoleAutoscrollResult && byRoleAutoscrollResult.cancelled === true,
            estimatedTotalPairs: byRoleAutoscrollResult && Number.isFinite(byRoleAutoscrollResult.estimatedTotalPairs)
                ? byRoleAutoscrollResult.estimatedTotalPairs
                : estimatedTotalPairs
        };
    }

    if (byRoleAutoscrollResult && byRoleAutoscrollResult.cancelled === true) {
        return {
            source: 'data-message-author-role-autoscroll',
            url: window.location.href,
            title: document.title,
            messages: [],
            cancelled: true
        };
    }

    return {
        source: 'data-message-author-role-autoscroll',
        url: window.location.href,
        title: document.title,
        messages: [],
        cancelled: false
    };
}

document.addEventListener('DOMContentLoaded', () => {
    questionsColumnEl = document.getElementById('questionsColumn');
    answersColumnEl = document.getElementById('answersColumn');
    questionsSearchInputEl = document.getElementById('questionsSearchInput');
    answersSearchInputEl = document.getElementById('answersSearchInput');
    questionsSearchPrevEl = document.getElementById('questionsSearchPrev');
    questionsSearchNextEl = document.getElementById('questionsSearchNext');
    questionsSearchCountEl = document.getElementById('questionsSearchCount');
    answersSearchPrevEl = document.getElementById('answersSearchPrev');
    answersSearchNextEl = document.getElementById('answersSearchNext');
    answersSearchCountEl = document.getElementById('answersSearchCount');
    questionsStatsEl = document.getElementById('questionsStats');
    answersStatsEl = document.getElementById('answersStats');
    saveButtonEl = document.getElementById('saveSession');
    stopButtonEl = document.getElementById('stopScript');
    scrapeModeSelectEl = document.getElementById('scrapeMode');
    loadingPanelEl = document.getElementById('loadingPanel');
    loadingStatusEl = document.getElementById('loadingStatus');
    loadingPercentEl = document.getElementById('loadingPercent');
    loadingBarEl = document.getElementById('loadingBar');
    loadingEtaEl = document.getElementById('loadingEta');
    const clearHistoryButtonEl = document.getElementById('clearHistory');
    const exportQaButtonEl = document.getElementById('exportQaFile');
    const copyQuestionsButtonEl = document.getElementById('copyQuestions');
    const copyAnswersButtonEl = document.getElementById('copyAnswers');
    const processingHelpButtonEl = document.getElementById('processingHelpButton');
    const processingHelpPopoverEl = document.getElementById('processingHelpPopover');

    setStopButtonState(false, false);
    setScrapeModeControlState(false);
    chrome.runtime.onMessage.addListener(handleRuntimeProgressMessage);

    const setProcessingHelpOpen = (isOpen) => {
        if (!processingHelpButtonEl || !processingHelpPopoverEl) {
            return;
        }

        processingHelpButtonEl.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        processingHelpPopoverEl.hidden = !isOpen;
    };

    if (processingHelpButtonEl && processingHelpPopoverEl) {
        processingHelpButtonEl.addEventListener('click', (event) => {
            event.stopPropagation();
            const isOpen = processingHelpButtonEl.getAttribute('aria-expanded') === 'true';
            setProcessingHelpOpen(!isOpen);
        });

        processingHelpPopoverEl.addEventListener('click', (event) => {
            event.stopPropagation();
        });

        document.addEventListener('click', () => {
            setProcessingHelpOpen(false);
        });
    }

    saveButtonEl.addEventListener('click', () => {
        clearUiForNewRun();
        saveAndProcessChatSession();
    });

    stopButtonEl.addEventListener('click', () => {
        requestStopCurrentRun();
    });

    exportQaButtonEl.addEventListener('click', () => {
        downloadCurrentPairsAsText();
    });

    clearHistoryButtonEl.addEventListener('click', () => {
        requestStopCurrentRun();
        activeRunId = '';
        activeRunTabId = null;
        activeTotalPairs = 0;
        activeApproxPairEstimate = 0;
        activeStage2EstimatedDurationMs = 0;
        lastPersistedProgressCheckpointUnits = 0;
        stopRequested = false;
        stopInProgress = false;
        resetLiveParseState();
        stopLoadingProgress(false);
        forceHideLoadingPanel();
        localStorage.removeItem(STORAGE_KEY);
        clearPageCheckpointFromActiveTab();
        clearColumns();
        setStopButtonState(false, false);
        setScrapeModeControlState(false);
    });

    copyQuestionsButtonEl.addEventListener('click', () => {
        copyTextToClipboard(currentQuestions.join('\n\n'));
    });

    copyAnswersButtonEl.addEventListener('click', () => {
        copyTextToClipboard(currentAnswers.join('\n\n'));
    });

    const bindSearchControls = (column, inputEl, prevEl, nextEl, contentEl) => {
        if (inputEl) {
            inputEl.addEventListener('focus', () => {
                activeSearchColumn = column;
            });

            inputEl.addEventListener('input', () => {
                applySearchQuery(column, inputEl.value, true);
            });

            inputEl.addEventListener('keydown', (event) => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    moveSearchMatch(column, event.shiftKey ? -1 : 1);
                }
            });
        }

        if (prevEl) {
            prevEl.addEventListener('click', () => {
                activeSearchColumn = column;
                moveSearchMatch(column, -1);
            });
        }

        if (nextEl) {
            nextEl.addEventListener('click', () => {
                activeSearchColumn = column;
                moveSearchMatch(column, 1);
            });
        }

        if (contentEl) {
            contentEl.addEventListener('click', () => {
                activeSearchColumn = column;
            });
        }
    };

    bindSearchControls(
        SEARCH_COLUMN_QUESTIONS,
        questionsSearchInputEl,
        questionsSearchPrevEl,
        questionsSearchNextEl,
        questionsColumnEl
    );
    bindSearchControls(
        SEARCH_COLUMN_ANSWERS,
        answersSearchInputEl,
        answersSearchPrevEl,
        answersSearchNextEl,
        answersColumnEl
    );

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            setProcessingHelpOpen(false);
        }

        const isFindShortcut = (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'f';
        if (isFindShortcut) {
            event.preventDefault();
            const targetInput = activeSearchColumn === SEARCH_COLUMN_ANSWERS
                ? answersSearchInputEl
                : questionsSearchInputEl;
            if (targetInput) {
                targetInput.focus();
                targetInput.select();
            }
            return;
        }

        const isNextShortcut = (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'g';
        if (isNextShortcut) {
            event.preventDefault();
            moveSearchMatch(activeSearchColumn, event.shiftKey ? -1 : 1);
        }
    });

    loadChatHistory();
    startPageCheckpointRefresh();
    updateSearchControls(SEARCH_COLUMN_QUESTIONS);
    updateSearchControls(SEARCH_COLUMN_ANSWERS);

    requestAnimationFrame(() => {
        logPopupOverflowDiagnostics('raf');
    });
    setTimeout(() => {
        logPopupOverflowDiagnostics('t+250ms');
    }, 250);
    window.addEventListener('resize', () => {
        logPopupOverflowDiagnostics('resize');
    });
    window.addEventListener('unload', () => {
        stopPageCheckpointRefresh();
    });
});
