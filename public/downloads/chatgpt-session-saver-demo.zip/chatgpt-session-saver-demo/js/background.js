chrome.runtime.onInstalled.addListener(() => {
    console.log("ChatGPT Session Saver installed!");
});
